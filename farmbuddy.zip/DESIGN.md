# FarmBuddy Design Brief

**Purpose**: Accessible AI advisory platform for Indian farmers (including illiterate users). Icon-based, mobile-first, earth-tone colors.

## Visual Direction

Tone: Calm, practical, welcoming, accessible. Agricultural context with warm earth tones and high contrast for readability.
Differentiation: Icon-driven interface with minimal text. Large 44px+ touch targets. No complexity. Mobile-first layout respects farmer workflows.
Aesthetic: Organic, utilitarian, anti-corporate. Greens for growth, browns for soil, yellows for sun.

## Color Palette

| Role | OKLCH | Hex | Usage |
|------|-------|-----|-------|
| Sage Green (Primary) | 0.58 0.08 140 | #689B6D | Main actions, crop health |
| Warm Brown (Secondary) | 0.54 0.09 30 | #8B6F47 | Soil, earth, secondary actions |
| Golden Yellow (Accent) | 0.70 0.12 65 | #D4A574 | Highlights, alerts, active states |
| Cream (Background) | 0.96 0.02 120 | #F5F3F0 | Main background, cards |
| Dark Foreground | 0.18 0.04 140 | #1A3D2E | Text, high contrast |
| Muted | 0.88 0.03 120 | #E8E4E0 | Borders, subtle dividers |
| Destructive | 0.60 0.18 25 | #C24A4A | Warnings, disease alerts |

## Typography

| Layer | Font | Size | Weight | Role |
|-------|------|------|--------|------|
| Display | Space Grotesk | 28-32px | 700 | Page titles, headings |
| Body | Nunito | 16-18px | 400-600 | Body text, instructions |
| Mono | JetBrains Mono | 14px | 400 | Code, technical info |

Minimum readable size: 18px for body text. 20px+ for UI labels. Large line-height (1.6) for clarity.

## Structural Zones

| Zone | Background | Treatment | Purpose |
|------|------------|-----------|----------|
| Header | Sage Green | Solid, border-bottom | Logo, branding, language select |
| Main Content | Cream | Card grid, 16px gaps | Advisory panels, crop cards, query input |
| Footer | Muted | Subtle, border-top | Legal, links, version info |
| Icon Buttons | Transparent | 44x44px minimum | Crop select, disease report, fertilizer |

## Spacing and Rhythm

Base unit: 4px. Padding in cards: 16px. Gaps between sections: 24px. Touch targets: 44x44px minimum.
Density: Spacious on mobile. Icons + 1 line of text per button. No compression.

## Component Patterns

Icon Buttons: 44x44px, centered icon, optional label below (max 2 lines). Hover: bg-muted. Active: scale-95.
Info Cards: Rounded 12px, bg-card, border-bottom in primary or accent color. Icon + heading + description.
Input: 44px height, bg-input, border subtle, focus ring in primary. Text 18px.
Button: 44px height, bg-primary, text cream, rounded 8px. Hover: opacity-90. Active: scale-95.

## Motion

Transition default: 0.3s cubic-bezier(0.4, 0, 0.2, 1). Used for hover states, focus rings, color changes. No bounce, no elastic easing. Subtle fade-in (0.3s) for page load.

## Dark Mode

Background: 0.16 0.01 140 (near-black green). Foreground: 0.94 0.02 120 (off-white cream). Primary: 0.72 0.10 140 (lighter green). Same earth-tone palette; lightness inverted for readability. Card contrast maintained at AA+.

## Accessibility Features

Touch targets: All interactive elements >= 44x44px.
Contrast: 7:1+ light mode (dark foreground on cream). 6:1+ dark mode (light foreground on dark green).
Icons + Text: Every button has icon + optional label. No icon-only buttons except universal (back, close).
High Legibility: Minimum 18px body text. Line-height 1.6. No thin fonts.
Focus Rings: Visible 2px ring in primary color. Never hidden.

## Constraints

No gradients (solid colors only for clarity).
No animations beyond fade-in and hover transitions.
No decorative elements (photos/illustrations minimal).
Mobile-first: breakpoint at 768px for tablet; 1024px for desktop.
No shadows deeper than lg (0 10px 15px -3px).

## Signature Detail

Icon library: Consistent 24px icons (crop, water droplet, leaf, pest, soil, sun, wind, settings, language). Simple, flat, no gradients. Used across all UI surfaces to enable icon-first navigation for illiterate farmers.
