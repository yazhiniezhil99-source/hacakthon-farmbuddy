import Storage "mo:caffeineai-object-storage/Storage";
import AdvisoryTypes "../types/advisory";
import List "mo:core/List";
import AdvisoryLib "../lib/advisory";

mixin (
  state : { var nextQueryId : Nat; recentQueries : List.List<AdvisoryTypes.QueryResult> },
) {
  // Submits a text query about crops/fertilizers and stores it in session history
  // language: ISO-style code — en, hi, ta, te, kn, ml, bn, mr, gu, pa, or, as, ur
  public func submitQuery(question : Text, language : Text) : async AdvisoryTypes.QueryResult {
    AdvisoryLib.answerQuery(question, language, state);
  };

  // Returns up to 5 most recent queries from current session
  public query func getRecentQueries() : async [AdvisoryTypes.QueryResult] {
    let size = state.recentQueries.size();
    let take : Nat = if (size > 5) 5 else size;
    state.recentQueries.sliceToArray(0, take);
  };

  // Returns all diseases in the built-in knowledge base
  public query func listDiseases() : async [AdvisoryTypes.DiseaseRecord] {
    AdvisoryLib.getAllDiseases();
  };

  // Detects disease from a list of symptom keywords
  public query func detectDiseaseFromSymptoms(
    symptoms : [Text]
  ) : async AdvisoryTypes.DiseaseDetectionResult {
    AdvisoryLib.detectDiseaseFromSymptoms(symptoms);
  };

  // Accepts a crop photo upload and returns disease detection results
  public func uploadCropPhoto(
    blob : Storage.ExternalBlob,
    cropHint : ?Text,
  ) : async AdvisoryTypes.PhotoUploadResult {
    let uploadId = state.nextQueryId;
    state.nextQueryId += 1;
    let detectionResult = AdvisoryLib.detectDiseaseFromPhoto(blob, cropHint);
    { uploadId; blob; detectionResult };
  };
};
