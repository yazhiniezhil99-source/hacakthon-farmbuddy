import CropTypes "../types/crops";
import CropLib "../lib/crops";

mixin () {
  // Returns all crops in the built-in library
  public query func listCrops() : async [CropTypes.Crop] {
    CropLib.getAllCrops();
  };

  // Returns a single crop by its id
  public query func getCrop(id : CropTypes.CropId) : async ?CropTypes.Crop {
    CropLib.getCrop(id);
  };

  // Returns fertilizer recommendation for a crop and soil combination
  public query func getFertilizerRecommendation(
    cropId : CropTypes.CropId,
    soilType : CropTypes.SoilType,
  ) : async ?CropTypes.FertilizerRecommendation {
    CropLib.getFertilizerRecommendation(cropId, soilType);
  };

  // Returns crops suitable for the given season
  public query func listCropsBySeason(season : CropTypes.Season) : async [CropTypes.Crop] {
    CropLib.getCropsBySeason(season);
  };

  // Returns crops suitable for the given soil type
  public query func listCropsBySoilType(soilType : CropTypes.SoilType) : async [CropTypes.Crop] {
    CropLib.getCropsBySoilType(soilType);
  };
};
