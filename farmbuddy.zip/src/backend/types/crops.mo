
module {
  public type CropId = Text;

  public type Season = {
    #kharif;
    #rabi;
    #zaid;
    #yearRound;
  };

  public type SoilType = {
    #sandy;
    #loamy;
    #clayey;
    #silty;
    #peaty;
    #chalky;
    #saline;
  };

  public type WaterNeed = {
    #low;
    #medium;
    #high;
  };

  public type NPKRatio = {
    nitrogen : Nat;
    phosphorus : Nat;
    potassium : Nat;
  };

  public type FertilizerRecommendation = {
    npkRatio : NPKRatio;
    fertilizerTypes : [Text];
    applicationSchedule : Text;
    notes : Text;
  };

  public type SoilFertilizerMap = {
    soilType : SoilType;
    recommendation : FertilizerRecommendation;
  };

  public type Crop = {
    id : CropId;
    name : Text;
    localNames : [Text];
    season : Season;
    soilRequirements : [SoilType];
    waterNeed : WaterNeed;
    growingDurationDays : Nat;
    commonPests : [Text];
    fertilizerRecommendations : [SoilFertilizerMap];
    generalAdvice : Text;
  };
};
