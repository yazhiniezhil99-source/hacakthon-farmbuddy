module {
  public type Timestamp = Int;
  public type SessionId = Text;
};
