import Storage "mo:caffeineai-object-storage/Storage";

module {
  public type QueryId = Nat;

  public type DiseaseId = Text;

  public type DiseaseSeverity = {
    #mild;
    #moderate;
    #severe;
  };

  public type DiseaseRecord = {
    id : DiseaseId;
    name : Text;
    affectedCrops : [Text];
    symptoms : [Text];
    description : Text;
    treatment : Text;
    preventionTips : [Text];
  };

  public type DiseaseDetectionResult = {
    disease : ?DiseaseRecord;
    confidence : Text;
    additionalNotes : Text;
  };

  public type QueryCategory = {
    #fertilizer;
    #disease;
    #pest;
    #irrigation;
    #general;
  };

  public type QueryResult = {
    id : QueryId;
    question : Text;
    answer : Text;
    category : QueryCategory;
    relatedCrops : [Text];
  };

  public type PhotoUploadResult = {
    uploadId : Nat;
    blob : Storage.ExternalBlob;
    detectionResult : DiseaseDetectionResult;
  };
};
