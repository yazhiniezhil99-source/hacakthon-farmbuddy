import MixinObjectStorage "mo:caffeineai-object-storage/Mixin";
import Storage "mo:caffeineai-object-storage/Storage";
import MixinCropsApi "mixins/crops-api";
import MixinAdvisoryApi "mixins/advisory-api";
import AdvisoryTypes "types/advisory";
import List "mo:core/List";

actor {
  // Session state — in-memory, resets on restart
  let advisoryState = {
    var nextQueryId : Nat = 0;
    recentQueries = List.empty<AdvisoryTypes.QueryResult>();
  };

  // Object storage infrastructure (required by extension)
  include MixinObjectStorage();

  // Crop library public API
  include MixinCropsApi();

  // Advisory/query/disease public API
  include MixinAdvisoryApi(advisoryState);
};
