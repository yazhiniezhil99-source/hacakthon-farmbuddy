import Types "../types/crops";

module {
  // Returns the built-in crop knowledge base
  public func getAllCrops() : [Types.Crop] {
    [
      {
        id = "rice";
        name = "Rice";
        localNames = ["Chawal", "Dhan", "Arisi", "Bhat", "Akki"];
        season = #kharif;
        soilRequirements = [#loamy, #clayey, #silty];
        waterNeed = #high;
        growingDurationDays = 120;
        commonPests = ["Stem borer", "Brown plant hopper", "Leaf folder", "Rice blast", "Sheath blight"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 120; phosphorus = 60; potassium = 60 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "Zinc Sulphate"];
              applicationSchedule = "Basal: 30% N + full P + K at transplanting. Top dress: 30% N at tillering, 40% N at panicle initiation.";
              notes = "Apply Zinc Sulphate 25 kg/ha if zinc deficiency is observed. Split urea application reduces nitrogen loss.";
            };
          },
          {
            soilType = #clayey;
            recommendation = {
              npkRatio = { nitrogen = 100; phosphorus = 50; potassium = 50 };
              fertilizerTypes = ["Urea", "SSP", "MOP"];
              applicationSchedule = "Basal: 25% N + full P + K. Top dress in 2 splits at active tillering and booting stage.";
              notes = "Clay soils retain nutrients well — reduce N slightly. Watch for iron toxicity in waterlogged conditions.";
            };
          },
          {
            soilType = #sandy;
            recommendation = {
              npkRatio = { nitrogen = 140; phosphorus = 70; potassium = 70 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "FYM"];
              applicationSchedule = "Apply FYM 10 t/ha before puddling. Split N into 4 equal doses to prevent leaching.";
              notes = "Sandy soils leach nutrients quickly. Incorporate organic matter to improve water and nutrient retention.";
            };
          }
        ];
        generalAdvice = "Maintain 5 cm standing water during vegetative stage. Drain 10 days before harvest. Use certified seeds and practice integrated pest management. Line transplanting at 20x15 cm spacing improves yield.";
      },
      {
        id = "wheat";
        name = "Wheat";
        localNames = ["Gehun", "Gom", "Godambu", "Godhuma"];
        season = #rabi;
        soilRequirements = [#loamy, #clayey, #silty];
        waterNeed = #medium;
        growingDurationDays = 120;
        commonPests = ["Aphids", "Rust (yellow/brown/black)", "Loose smut", "Karnal bunt", "Termites"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 120; phosphorus = 60; potassium = 40 };
              fertilizerTypes = ["Urea", "DAP", "MOP"];
              applicationSchedule = "Basal: full P + K + 50% N at sowing. Top dress: 25% N at first irrigation (21 days), 25% N at second irrigation (45 days).";
              notes = "Timely sowing (Nov 1–15) is critical. Late sowing (after Nov 25) reduces yield. Apply sulfur 20 kg/ha for quality protein.";
            };
          },
          {
            soilType = #clayey;
            recommendation = {
              npkRatio = { nitrogen = 100; phosphorus = 50; potassium = 30 };
              fertilizerTypes = ["Urea", "SSP", "Potash"];
              applicationSchedule = "Basal: full P + K + 40% N. Top dress: 30% N at CRI stage, 30% N at flag leaf stage.";
              notes = "Clay soils provide good moisture retention. Ensure good drainage to prevent waterlogging which causes root rot.";
            };
          }
        ];
        generalAdvice = "Use HD-2967 or GW-322 certified seeds. Ensure 6 irrigations at critical growth stages: CRI, tillering, jointing, booting, heading, and milky grain. Seed treatment with Thiram protects against smut diseases.";
      },
      {
        id = "corn";
        name = "Corn (Maize)";
        localNames = ["Makka", "Makai", "Cholam", "Jonnalu"];
        season = #kharif;
        soilRequirements = [#loamy, #sandy, #silty];
        waterNeed = #medium;
        growingDurationDays = 90;
        commonPests = ["Fall armyworm", "Stem borer", "Aphids", "Silk cut", "Downy mildew"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 150; phosphorus = 75; potassium = 85 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "Zinc Sulphate"];
              applicationSchedule = "Basal: full P + K + 1/3 N at sowing. Top dress: 1/3 N at 30 days, 1/3 N at tasseling.";
              notes = "Apply Zinc Sulphate 25 kg/ha if zinc deficient. Maize is sensitive to sulfur deficiency — apply 20 kg/ha sulfur if needed.";
            };
          },
          {
            soilType = #sandy;
            recommendation = {
              npkRatio = { nitrogen = 180; phosphorus = 90; potassium = 100 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "FYM"];
              applicationSchedule = "Incorporate 10 t/ha FYM before sowing. Split N into 4–5 doses throughout the season to minimize leaching.";
              notes = "Sandy soils require more frequent irrigation and fertilization. Mulching conserves moisture.";
            };
          }
        ];
        generalAdvice = "Sow at 60x20 cm spacing. Ensure pollination by growing in blocks (min 4 rows). Thinning at 2-leaf stage to 1 plant per hill. Harvest when husk turns brown and kernels are firm. Proper cob storage prevents aflatoxin contamination.";
      },
      {
        id = "sugarcane";
        name = "Sugarcane";
        localNames = ["Ganna", "Ikku", "Cheruku", "Kabbu"];
        season = #yearRound;
        soilRequirements = [#loamy, #clayey];
        waterNeed = #high;
        growingDurationDays = 365;
        commonPests = ["Internode borer", "Top shoot borer", "Root grub", "Scale insect", "Red rot", "Wilt"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 250; phosphorus = 115; potassium = 115 };
              fertilizerTypes = ["Urea", "SSP", "MOP", "FYM", "Press mud"];
              applicationSchedule = "Basal: full P + 1/3 N + 1/3 K at planting. 1/3 N + 1/3 K at 60 days. 1/3 N + 1/3 K at 120 days.";
              notes = "Apply 25 t/ha press mud or FYM at planting. Ratoon crop requires 75% of plant crop dose. Use biofertilizers Azospirillum + Phosphobacteria to reduce chemical fertilizer use.";
            };
          },
          {
            soilType = #clayey;
            recommendation = {
              npkRatio = { nitrogen = 200; phosphorus = 100; potassium = 100 };
              fertilizerTypes = ["Urea", "DAP", "MOP"];
              applicationSchedule = "Split into 3 equal doses at planting, 60 days, and 90 days after planting.";
              notes = "Ensure proper drainage in clay soils. Waterlogging leads to root rot and reduces juice quality.";
            };
          }
        ];
        generalAdvice = "Use disease-free setts with 3 buds. Treat setts with Carbendazim before planting. Maintain furrow irrigation. Earthing up at 90 days improves lodging resistance. Trash mulching conserves moisture and suppresses weeds.";
      },
      {
        id = "cotton";
        name = "Cotton";
        localNames = ["Kapas", "Karpas", "Parathi", "Patti"];
        season = #kharif;
        soilRequirements = [#loamy, #clayey, #silty];
        waterNeed = #medium;
        growingDurationDays = 180;
        commonPests = ["Bollworm (American/Spotted/Pink)", "Thrips", "Whitefly", "Jassid", "Cotton leafhopper", "Sucking pests"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 150; phosphorus = 75; potassium = 75 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "Boron"];
              applicationSchedule = "Basal: full P + K + 50% N. Top dress: 25% N at 45 days (squaring), 25% N at 60 days (flowering).";
              notes = "Apply Boron 1–2 kg/ha for boll setting. Micronutrient deficiencies (Boron, Zinc) are common in cotton — foliar sprays at flowering stage.";
            };
          },
          {
            soilType = #clayey;
            recommendation = {
              npkRatio = { nitrogen = 120; phosphorus = 60; potassium = 60 };
              fertilizerTypes = ["Urea", "SSP", "MOP"];
              applicationSchedule = "Basal: full P + K + 40% N. Top dress: 30% N at squaring, 30% N at boll development.";
              notes = "Black cotton soil is inherently fertile. Reduce fertilizer dosage if soil test shows high native fertility.";
            };
          }
        ];
        generalAdvice = "Use Bt cotton hybrids for bollworm resistance. Sow at 90x60 cm spacing for Bt hybrids. Install pheromone traps (5/acre) for bollworm monitoring. Pick cotton at weekly intervals when bolls are 70% open. Avoid defoliation by excess irrigation in late season.";
      },
      {
        id = "tomato";
        name = "Tomato";
        localNames = ["Tamatar", "Thakkali", "Tomato", "Tameta"];
        season = #yearRound;
        soilRequirements = [#loamy, #sandy, #silty];
        waterNeed = #medium;
        growingDurationDays = 75;
        commonPests = ["Fruit borer", "Leaf miner", "Whitefly", "Aphids", "Early blight", "Late blight", "Bacterial wilt"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 120; phosphorus = 80; potassium = 80 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "Calcium Nitrate"];
              applicationSchedule = "Basal: full P + K + 1/3 N at transplanting. Top dress: 1/3 N at 30 days, 1/3 N at flowering/fruiting.";
              notes = "Apply Calcium Nitrate 2% foliar spray at flowering to prevent blossom end rot. Boron 0.2% foliar spray improves fruit set.";
            };
          },
          {
            soilType = #sandy;
            recommendation = {
              npkRatio = { nitrogen = 150; phosphorus = 100; potassium = 100 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "FYM"];
              applicationSchedule = "Incorporate 25 t/ha FYM. Drip fertigation: 3–4 splits of N + K throughout growing season.";
              notes = "Drip irrigation with fertigation gives best results in sandy soils. Mulching reduces evaporation and weed pressure.";
            };
          }
        ];
        generalAdvice = "Raise nursery in protected beds. Transplant 25–30 day old seedlings. Stake plants at 30 cm height. Remove suckers below first flower cluster. Harvest at breaker stage for long-distance transport, full red stage for local markets.";
      },
      {
        id = "onion";
        name = "Onion";
        localNames = ["Pyaaz", "Kanda", "Vengayam", "Eerulli"];
        season = #rabi;
        soilRequirements = [#loamy, #sandy, #silty];
        waterNeed = #medium;
        growingDurationDays = 120;
        commonPests = ["Thrips", "Purple blotch", "Stemphylium blight", "Basal rot", "Downy mildew"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 100; phosphorus = 50; potassium = 100 };
              fertilizerTypes = ["Urea", "SSP", "MOP", "Sulphur"];
              applicationSchedule = "Basal: full P + K + 50% N at transplanting. Top dress: 50% N in 2 splits at 30 and 45 days after transplanting.";
              notes = "Onion requires high potassium for bulb development. Apply Sulphur 30 kg/ha for pungency and shelf life. Stop irrigation 15 days before harvest.";
            };
          },
          {
            soilType = #sandy;
            recommendation = {
              npkRatio = { nitrogen = 120; phosphorus = 60; potassium = 120 };
              fertilizerTypes = ["Urea", "SSP", "MOP", "FYM"];
              applicationSchedule = "Incorporate 20 t/ha FYM before transplanting. Fertigation through drip: split N + K in 8–10 doses.";
              notes = "Sandy soils drain quickly — use drip irrigation. High K ensures good bulb development.";
            };
          }
        ];
        generalAdvice = "Raise seedlings in raised beds. Transplant 6–8 week old seedlings at 15x10 cm. Weed management critical in first 30 days. Harvest when 50% tops fall. Cure in field for 3–5 days before storage. Store in well-ventilated cool place.";
      },
      {
        id = "potato";
        name = "Potato";
        localNames = ["Aloo", "Batata", "Urulaikizhangu", "Bangaladumpa"];
        season = #rabi;
        soilRequirements = [#loamy, #sandy, #silty];
        waterNeed = #medium;
        growingDurationDays = 90;
        commonPests = ["Late blight", "Early blight", "Aphids", "White grub", "Cutworm", "Black scurf"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 180; phosphorus = 90; potassium = 180 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "FYM"];
              applicationSchedule = "Incorporate 25 t/ha FYM 2 weeks before planting. Basal: full P + full K + 50% N. Top dress: 50% N at earthing up (30–35 days).";
              notes = "Potassium is critical for tuber development and quality. Apply Calcium at tuber initiation to prevent hollow heart.";
            };
          },
          {
            soilType = #sandy;
            recommendation = {
              npkRatio = { nitrogen = 200; phosphorus = 100; potassium = 200 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "FYM", "Micronutrients"];
              applicationSchedule = "Heavy FYM application. Split N + K in 3 doses. Use drip fertigation if available.";
              notes = "Sandy soils give well-shaped tubers but require more water. Ensure adequate soil moisture during tuber filling.";
            };
          }
        ];
        generalAdvice = "Use certified seed tubers. Cut tubers with at least 2–3 eyes and treat with Mancozeb. Plant at 60x20 cm. First earthing up at 25 days, second at 45 days. Monitor for late blight — spray Mancozeb/Chlorothalonil preventively in humid weather. Harvest when tops dry.";
      },
      {
        id = "mango";
        name = "Mango";
        localNames = ["Aam", "Manga", "Mavinahannu", "Mamidi"];
        season = #yearRound;
        soilRequirements = [#loamy, #sandy, #clayey];
        waterNeed = #low;
        growingDurationDays = 1825;
        commonPests = ["Mango hopper", "Mealy bug", "Fruit fly", "Stem borer", "Anthracnose", "Powdery mildew"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 500; phosphorus = 200; potassium = 500 };
              fertilizerTypes = ["Urea", "SSP", "MOP", "FYM", "Micronutrients"];
              applicationSchedule = "For bearing trees (7+ years): Apply FYM 50 kg/tree in May. Full P in October. Split N + K: 50% Oct-Nov and 50% February. Young trees get proportional doses by year.";
              notes = "Doses per year 1–7 are progressive. Foliar spray of 0-52-34 (MAP) at panicle emergence improves fruit set. Boron 0.3% spray at panicle initiation prevents fruit drop.";
            };
          },
          {
            soilType = #sandy;
            recommendation = {
              npkRatio = { nitrogen = 600; phosphorus = 250; potassium = 600 };
              fertilizerTypes = ["Urea", "SSP", "MOP", "FYM", "Vermicompost"];
              applicationSchedule = "Increase organic matter with 75 kg/tree FYM annually. Apply in basin method in 2 splits.";
              notes = "Sandy soils drain fast. Basin irrigation with mulching conserves moisture around root zone.";
            };
          }
        ];
        generalAdvice = "Plant at 10x10 m spacing (100 trees/ha). Fruit bearing starts at 4–5 years for grafted plants. Apply growth regulators (NAA 20 ppm) if alternate bearing is a problem. Harvest when stalk end yellows and fruit releases a sweet aroma. Post-harvest: sort, grade, and pack with care to minimize bruising.";
      },
      {
        id = "mustard";
        name = "Mustard";
        localNames = ["Sarson", "Rai", "Kadugu", "Avalu"];
        season = #rabi;
        soilRequirements = [#loamy, #sandy, #silty];
        waterNeed = #low;
        growingDurationDays = 110;
        commonPests = ["Aphids", "Painted bug", "Sawfly", "Alternaria blight", "White rust", "Powdery mildew"];
        fertilizerRecommendations = [
          {
            soilType = #loamy;
            recommendation = {
              npkRatio = { nitrogen = 80; phosphorus = 40; potassium = 40 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "Sulphur"];
              applicationSchedule = "Basal: full P + K + 50% N at sowing. Top dress: 50% N at first irrigation (25–30 days after sowing).";
              notes = "Mustard is a sulfur-hungry crop. Apply Gypsum 200 kg/ha or Sulphur 30 kg/ha for high oil content. Boron deficiency causes hollow stem — apply 0.2% borax spray.";
            };
          },
          {
            soilType = #sandy;
            recommendation = {
              npkRatio = { nitrogen = 100; phosphorus = 50; potassium = 50 };
              fertilizerTypes = ["Urea", "DAP", "MOP", "Gypsum", "FYM"];
              applicationSchedule = "Incorporate 10 t/ha FYM. Full Gypsum at sowing. Split N into 3 doses.";
              notes = "Sandy soils lose sulfur through leaching — apply sulfur in multiple doses.";
            };
          }
        ];
        generalAdvice = "Timely sowing (Oct 15 – Nov 15) gives best yields. Use certified PM-25 or Varuna variety seeds. Row spacing 30x10 cm. Thinning at 15 days to maintain plant population. Apply thiamethoxam seed treatment against aphids. Harvest when 75% pods turn straw-colored.";
      }
    ];
  };

  // Returns a specific crop by id
  public func getCrop(id : Types.CropId) : ?Types.Crop {
    let crops = getAllCrops();
    crops.find(func(c) { c.id == id });
  };

  // Returns fertilizer recommendations for a given crop and soil type
  public func getFertilizerRecommendation(
    cropId : Types.CropId,
    soilType : Types.SoilType,
  ) : ?Types.FertilizerRecommendation {
    switch (getCrop(cropId)) {
      case null null;
      case (?crop) {
        let match = crop.fertilizerRecommendations.find(func(sfm) { sfm.soilType == soilType });
        switch (match) {
          case null {
            // Fall back to first available recommendation if exact soil type not found
            switch (crop.fertilizerRecommendations.size() > 0) {
              case true ?crop.fertilizerRecommendations[0].recommendation;
              case false null;
            };
          };
          case (?sfm) ?sfm.recommendation;
        };
      };
    };
  };

  // Returns crops suitable for a given season
  public func getCropsBySeason(season : Types.Season) : [Types.Crop] {
    let crops = getAllCrops();
    crops.filter(func(c) { c.season == season or c.season == #yearRound });
  };

  // Returns crops suitable for a given soil type
  public func getCropsBySoilType(soilType : Types.SoilType) : [Types.Crop] {
    let crops = getAllCrops();
    crops.filter(func(c) {
      c.soilRequirements.find(func(s) { s == soilType }) != null
    });
  };
};
