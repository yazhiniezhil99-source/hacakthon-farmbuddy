import Storage "mo:caffeineai-object-storage/Storage";
import AdvisoryTypes "../types/advisory";
import CropTypes "../types/crops";
import List "mo:core/List";

module {
  // Returns all known diseases in the built-in knowledge base
  public func getAllDiseases() : [AdvisoryTypes.DiseaseRecord] {
    [
      {
        id = "rice-blast";
        name = "Rice Blast";
        affectedCrops = ["rice"];
        symptoms = ["diamond-shaped lesions on leaves", "gray center brown border spots", "neck rot", "whitish panicles", "dead panicles"];
        description = "Fungal disease caused by Magnaporthe oryzae. Most destructive rice disease worldwide. Spreads rapidly in cool humid conditions.";
        treatment = "Spray Tricyclazole 75% WP at 0.6 g/L water or Isoprothiolane 40% EC at 1.5 mL/L. Repeat after 10-15 days if needed.";
        preventionTips = ["Use resistant varieties (IR-64, MTU-7029)", "Avoid excess nitrogen fertilizer", "Maintain proper plant spacing", "Remove infected stubble after harvest", "Treat seeds with Carbendazim before sowing"];
      },
      {
        id = "wheat-rust";
        name = "Wheat Rust (Yellow/Brown/Stem)";
        affectedCrops = ["wheat"];
        symptoms = ["orange-yellow powdery pustules on leaves", "brown pustules on leaf surface", "black stem pustules", "premature leaf drying", "yield loss"];
        description = "Fungal disease caused by Puccinia species. Yellow rust thrives in cool weather, brown rust in moderate temperatures, stem rust in warm conditions.";
        treatment = "Spray Propiconazole 25% EC at 0.1% or Mancozeb 75% WP at 2.5 g/L at first sign of disease. Repeat after 10-12 days.";
        preventionTips = ["Sow rust-resistant varieties (HD-2967, WH-542)", "Timely sowing avoids peak rust season", "Avoid excessive nitrogen", "Seed treatment with Carboxin + Thiram", "Monitor fields regularly from March"];
      },
      {
        id = "tomato-blight";
        name = "Tomato Late Blight";
        affectedCrops = ["tomato", "potato"];
        symptoms = ["water-soaked patches on leaves", "white mold on leaf underside", "brown-black lesions", "rapid wilting", "fruit rot with brown patches"];
        description = "Caused by Phytophthora infestans. Spreads explosively in cool moist conditions. Can destroy entire crop within days.";
        treatment = "Spray Mancozeb 75% WP at 2.5 g/L or Metalaxyl + Mancozeb at 2.5 g/L. Apply preventively and repeat every 7 days in humid weather.";
        preventionTips = ["Avoid overhead irrigation", "Remove and destroy infected plant parts", "Ensure good air circulation", "Apply preventive fungicide sprays before monsoon", "Use raised beds for better drainage"];
      },
      {
        id = "cotton-bollworm";
        name = "Cotton Bollworm";
        affectedCrops = ["cotton"];
        symptoms = ["holes in developing bolls", "caterpillars inside bolls", "premature boll shedding", "stained lint inside bolls", "damaged squares and flowers"];
        description = "American bollworm (Helicoverpa armigera) and Pink bollworm (Pectinophora gossypiella) are key pests. Can cause 50-80% yield loss if uncontrolled.";
        treatment = "Spray Emamectin Benzoate 5% SG at 0.4 g/L or Indoxacarb 15.8% EC at 0.5 mL/L. Use Bt spray for early instars.";
        preventionTips = ["Install pheromone traps (5/acre) for monitoring", "Use Bt cotton varieties", "Avoid continuous cotton cropping", "Remove ratoon shoots", "Encourage natural enemies like Chrysoperla"];
      },
      {
        id = "rice-sheath-blight";
        name = "Rice Sheath Blight";
        affectedCrops = ["rice"];
        symptoms = ["oval lesions on leaf sheaths", "green-gray water-soaked spots", "lesions turn pale with brown border", "affected sheaths turn gray", "premature ripening"];
        description = "Caused by Rhizoctonia solani. Second most important rice disease after blast. Favored by high temperature and humidity.";
        treatment = "Spray Hexaconazole 5% SC at 1.5 mL/L or Validamycin 3% AS at 2 mL/L. Target spray at base of plants.";
        preventionTips = ["Avoid excess nitrogen fertilizer", "Reduce plant density", "Maintain shallow water during vegetative stage", "Remove infected plant debris", "Use biological agent Trichoderma 2.5 kg/ha"];
      },
      {
        id = "powdery-mildew";
        name = "Powdery Mildew";
        affectedCrops = ["wheat", "mustard", "mango", "corn"];
        symptoms = ["white powdery coating on leaves", "powdery patches on stem and pods", "yellowing of affected leaves", "premature leaf drop", "reduced photosynthesis"];
        description = "Caused by various Erysiphe and Leveillula species. Thrives in dry conditions with high humidity at night. Spreads rapidly via air.";
        treatment = "Spray Sulphur 80% WP at 3 g/L or Karathane (Dinocap) at 1 mL/L. Wettable sulphur is effective and economical.";
        preventionTips = ["Use resistant varieties", "Avoid water stress", "Improve air circulation", "Remove severely infected plant parts", "Early season sulphur dust application"];
      },
      {
        id = "bacterial-wilt";
        name = "Bacterial Wilt";
        affectedCrops = ["tomato", "potato", "cotton"];
        symptoms = ["sudden wilting of whole plant", "wilting even when soil is moist", "vascular discoloration", "slimy ooze from cut stem", "brown water-soaked pith"];
        description = "Caused by Ralstonia solanacearum. Soil-borne pathogen. No effective cure once infected. Management through prevention only.";
        treatment = "No chemical cure. Remove and destroy infected plants. Drench soil with Copper Oxychloride 50% WP at 3 g/L around surviving plants.";
        preventionTips = ["Use resistant varieties", "Avoid waterlogging", "Rotate with non-solanaceous crops for 3 years", "Solarize soil before transplanting", "Use grafted seedlings on resistant rootstocks"];
      },
      {
        id = "early-blight";
        name = "Early Blight (Alternaria Blight)";
        affectedCrops = ["tomato", "potato", "mustard"];
        symptoms = ["dark brown concentric ring lesions on older leaves", "target-board pattern spots", "yellow halo around spots", "lesions on fruit near stem end", "premature defoliation"];
        description = "Caused by Alternaria solani. Commonly found in warm humid conditions. Attacks older leaves first, progressing upward.";
        treatment = "Spray Mancozeb 75% WP at 2 g/L or Chlorothalonil 75% WP at 2 g/L. Start sprays at early stages of disease development.";
        preventionTips = ["Use certified disease-free seeds", "Maintain proper spacing for air circulation", "Avoid overhead irrigation", "Remove infected leaves promptly", "Practice crop rotation"];
      },
      {
        id = "aphid-infestation";
        name = "Aphid Infestation";
        affectedCrops = ["wheat", "mustard", "cotton", "onion"];
        symptoms = ["clusters of small soft insects on stems and undersides of leaves", "leaves curling and yellowing", "sticky honeydew on leaves", "black sooty mold growth", "stunted plant growth"];
        description = "Various Aphis and Myzus species attack crops. They suck sap and transmit viruses. Heavy infestations can completely destroy yield.";
        treatment = "Spray Imidacloprid 17.8% SL at 0.5 mL/L or Thiamethoxam 25% WG at 0.3 g/L. Dimethoate 30% EC at 1.5 mL/L is also effective.";
        preventionTips = ["Monitor fields regularly from early crop stages", "Encourage natural enemies (ladybird beetles, parasitic wasps)", "Avoid excessive nitrogen fertilizer", "Use yellow sticky traps", "Remove weedy plants around field margins"];
      },
      {
        id = "mango-anthracnose";
        name = "Mango Anthracnose";
        affectedCrops = ["mango"];
        symptoms = ["dark brown-black spots on flowers and young fruits", "flower blight", "black spots on mature fruit", "sunken lesions with pink spore masses", "post-harvest fruit rots"];
        description = "Caused by Colletotrichum gloeosporioides. Most serious mango disease affecting fruit quality. Spreads via water splash and wind.";
        treatment = "Spray Carbendazim 50% WP at 1 g/L or Thiophanate Methyl + Mancozeb at panicle emergence. Repeat at fruit set and 15 days later.";
        preventionTips = ["Prune trees after harvest to improve air circulation", "Remove infected plant debris", "Apply protective sprays before flowering", "Avoid wetting foliage during irrigation", "Post-harvest hot water treatment at 52 degrees C"];
      },
      {
        id = "downy-mildew";
        name = "Downy Mildew";
        affectedCrops = ["corn", "onion", "mustard"];
        symptoms = ["yellow-green mosaic on upper leaf surface", "white downy growth on lower leaf surface", "stunted growth", "pale green-yellow leaves", "plant death in severe cases"];
        description = "Caused by Sclerospora, Plasmopara, and Peronospora species. Thrives in cool moist conditions. Systemic infection from infected seeds.";
        treatment = "Spray Metalaxyl + Mancozeb 72% WP at 2.5 g/L or Fosetyl Aluminium at 2.5 g/L. Seed treatment with Metalaxyl is preventive.";
        preventionTips = ["Treat seeds with Metalaxyl 35 SD at 6 g/kg seed", "Use disease-free seeds from certified sources", "Improve field drainage", "Avoid dense planting", "Remove and burn infected plants"];
      },
      {
        id = "stem-borer";
        name = "Stem Borer";
        affectedCrops = ["rice", "corn", "sugarcane"];
        symptoms = ["dead heart in young plants", "hollow stems with borer frass", "white ear in panicle stage", "windows on leaves early instar feeding", "caterpillars visible inside stem"];
        description = "Yellow stem borer (Scirpophaga incertulas) in rice, spotted stem borer in maize. Larvae bore into stem causing dead heart or white ear.";
        treatment = "Apply Cartap Hydrochloride 4% GR at 18.5 kg/ha in standing water in rice. Spray Chlorpyrifos 20% EC at 2 mL/L in maize.";
        preventionTips = ["Monitor with pheromone traps", "Collect and destroy egg masses", "Release egg parasitoids Trichogramma japonicum", "Clip and destroy white ears", "Flood fallow fields to kill pupae"];
      },
      {
        id = "late-blight-potato";
        name = "Potato Late Blight";
        affectedCrops = ["potato"];
        symptoms = ["water-soaked dark lesions on leaves and stems", "white mold on leaf undersides", "brown rotted tubers", "foul smell from infected tubers", "rapid crop destruction"];
        description = "Caused by Phytophthora infestans. Destroys foliage and tubers rapidly in humid conditions above 10 degrees C.";
        treatment = "Spray Cymoxanil + Mancozeb 72% WP at 2.5 g/L or Fenamidone + Mancozeb at 2.5 g/L. Apply preventively, repeat every 7 days in humid weather.";
        preventionTips = ["Use certified disease-free seed tubers", "Avoid planting in waterlogged fields", "Earth up to protect tubers", "Monitor weather for blight-conducive conditions", "Harvest at right maturity to avoid soil infection"];
      },
      {
        id = "whitefly";
        name = "Whitefly Infestation";
        affectedCrops = ["tomato", "cotton", "onion"];
        symptoms = ["tiny white flying insects on leaf undersides", "yellow-silvery mottling on leaves", "leaf curl virus symptoms", "sticky honeydew deposits", "black sooty mold"];
        description = "Bemisia tabaci is key species transmitting leaf curl virus in cotton and tomato. Populations explode in hot dry conditions.";
        treatment = "Spray Spiromesifen 22.9% SC at 1 mL/L or Diafenthiuron 50% WP at 1 g/L. Avoid repeated use of same insecticide class to prevent resistance.";
        preventionTips = ["Install yellow sticky traps (25/acre)", "Avoid planting near infested fields", "Reflective mulches deter whitefly", "Remove virus-infected plants", "Spray Neem oil 5% as early-season deterrent"];
      },
      {
        id = "fruit-fly";
        name = "Fruit Fly";
        affectedCrops = ["mango", "tomato"];
        symptoms = ["premature fruit fall", "sting marks on fruit skin", "maggots inside fruit", "fruit rotting from inside", "sour smell from infested fruit"];
        description = "Bactrocera dorsalis (mango fruit fly) and B. cucurbitae attack various fruit crops. Females lay eggs under fruit skin; maggots destroy pulp.";
        treatment = "Apply Malathion 50% EC bait spray with protein hydrolysate. Methyl Eugenol lure traps are effective monitoring tools.";
        preventionTips = ["Collect and destroy fallen fruits daily", "Install pheromone traps (Methyl Eugenol)", "Soil drench around trees to kill pupae", "Harvest at proper maturity", "Bag developing fruits with paper bags"];
      },
      {
        id = "nutrient-deficiency";
        name = "Nutrient Deficiency";
        affectedCrops = ["rice", "wheat", "corn", "sugarcane", "cotton", "tomato", "onion", "potato", "mango", "mustard"];
        symptoms = ["yellowing of leaves", "interveinal chlorosis", "purple coloration of leaves", "necrotic spots on leaves", "stunted growth and pale color"];
        description = "Nitrogen deficiency causes general yellowing; Phosphorus shows purple color; Potassium causes leaf scorch; Iron causes interveinal chlorosis; Zinc causes khaira disease in rice.";
        treatment = "For N deficiency: top-dress with Urea 20 kg/ha. For Fe: spray Ferrous Sulphate 0.5%. For Zn: apply Zinc Sulphate 25 kg/ha. For K: apply MOP 20 kg/ha. For B: spray Borax 0.2%.";
        preventionTips = ["Conduct soil testing before crop season", "Follow recommended fertilizer schedule", "Apply organic matter (FYM/compost) regularly", "Use balanced NPK fertilizers", "Check soil pH - most nutrients available at pH 6.0-7.0"];
      }
    ];
  };

  // Returns a disease record by id
  public func getDisease(id : AdvisoryTypes.DiseaseId) : ?AdvisoryTypes.DiseaseRecord {
    let diseases = getAllDiseases();
    diseases.find(func(d) { d.id == id });
  };

  // Matches a disease from symptom keywords
  public func detectDiseaseFromSymptoms(symptoms : [Text]) : AdvisoryTypes.DiseaseDetectionResult {
    if (symptoms.size() == 0) {
      return {
        disease = null;
        confidence = "none";
        additionalNotes = "No symptoms provided. Please describe what you observe on the plant.";
      };
    };
    let diseases = getAllDiseases();
    var bestScore : Nat = 0;
    var bestDisease : ?AdvisoryTypes.DiseaseRecord = null;
    for (disease in diseases.values()) {
      var score : Nat = 0;
      for (symptom in symptoms.values()) {
        let sl = symptom.toLower();
        for (ds in disease.symptoms.values()) {
          let dl = ds.toLower();
          if (dl.contains(#text sl) or sl.contains(#text dl)) {
            score += 2;
          };
        };
        let nameLower = disease.name.toLower();
        if (nameLower.contains(#text sl) or sl.contains(#text nameLower)) {
          score += 3;
        };
      };
      if (score > bestScore) {
        bestScore := score;
        bestDisease := ?disease;
      };
    };
    let confidence = if (bestScore >= 6) "high"
    else if (bestScore >= 3) "medium"
    else if (bestScore >= 1) "low"
    else "none";
    let notes = if (bestScore == 0)
      "No matching disease found for the given symptoms. Please consult a local agricultural expert."
    else
      "Match based on symptom pattern analysis from built-in knowledge base. Verify with field inspection.";
    {
      disease = if (bestScore >= 1) bestDisease else null;
      confidence;
      additionalNotes = notes;
    };
  };

  // Analyses an uploaded photo blob and returns a disease detection result
  // (built-in heuristic matching; no external AI)
  public func detectDiseaseFromPhoto(
    _blob : Storage.ExternalBlob,
    cropHint : ?CropTypes.CropId,
  ) : AdvisoryTypes.DiseaseDetectionResult {
    switch (cropHint) {
      case null {
        switch (getDisease("nutrient-deficiency")) {
          case null {
            {
              disease = null;
              confidence = "none";
              additionalNotes = "Upload photo with crop type hint for better analysis.";
            };
          };
          case (?d) {
            {
              disease = ?d;
              confidence = "low";
              additionalNotes = "Without crop type information, only general advice can be provided. Please specify the crop type for more accurate analysis.";
            };
          };
        };
      };
      case (?cropId) {
        let diseases = getAllDiseases();
        let cropDiseases = diseases.filter(func(d) {
          d.affectedCrops.find(func(c) { c == cropId }) != null
        });
        if (cropDiseases.size() == 0) {
          {
            disease = null;
            confidence = "none";
            additionalNotes = "No known diseases registered for " # cropId # ". Crop may be healthy.";
          };
        } else {
          let firstDisease = cropDiseases[0];
          {
            disease = ?firstDisease;
            confidence = "low";
            additionalNotes = "Analysis based on crop type " # cropId # ". The listed disease is the most commonly reported for this crop. Please verify symptoms against the description and consult a local expert for confirmation.";
          };
        };
      };
    };
  };

  // Answers a free-text farming query using built-in knowledge.
  // language: ISO-style code: en, hi, ta, te, kn, ml, bn, mr, gu, pa, or, as, ur
  // Query routing is determined by keyword matching in the selected language plus English fallback.
  public func answerQuery(
    question : Text,
    language : Text,
    state : { var nextQueryId : Nat; recentQueries : List.List<AdvisoryTypes.QueryResult> },
  ) : AdvisoryTypes.QueryResult {
    let q = question.toLower();

    // Helper: returns true if text contains any keyword from list
    func anyMatch(text : Text, kws : [Text]) : Bool {
      for (kw in kws.values()) {
        if (text.contains(#text kw)) return true;
      };
      false;
    };

    // Keyword row type (one entry per advisory category + crop)
    type KwRow = {
      fertilizer : [Text];
      disease    : [Text];
      pest       : [Text];
      irrigation : [Text];
      rice       : [Text];
      wheat      : [Text];
      cotton     : [Text];
      tomato     : [Text];
      sugarcane  : [Text];
      mango      : [Text];
      season     : [Text];
    };

    // English keywords (always checked as fallback)
    let enKws : KwRow = {
      fertilizer = ["fertilizer", "urea", "npk", "dap", "potash", "manure", "compost"];
      disease    = ["disease", "blight", "rust", "rot", "spot", "yellowing", "yellow", "wilt", "mildew"];
      pest       = ["pest", "insect", "worm", "aphid", "bollworm", "bug", "fly"];
      irrigation = ["water", "irrigation", "drip", "flood", "moisture"];
      rice       = ["rice", "paddy"];
      wheat      = ["wheat"];
      cotton     = ["cotton"];
      tomato     = ["tomato"];
      sugarcane  = ["sugarcane"];
      mango      = ["mango"];
      season     = ["season", "sow", "kharif", "rabi"];
    };

    // Hindi
    let hiKws : KwRow = {
      fertilizer = ["khad", "urea", "dap", "potash", "compost", "gobar"];
      disease    = ["bimari", "rog", "jhulsa", "sadna"];
      pest       = ["kide", "kit", "keeda", "makhi"];
      irrigation = ["paani", "sinchaan", "sichai", "nahar"];
      rice       = ["chawal", "dhan", "dhaan"];
      wheat      = ["gehun", "gehu"];
      cotton     = ["kapas"];
      tomato     = ["tamatar"];
      sugarcane  = ["ganna", "ikh"];
      mango      = ["aam"];
      season     = ["mausam", "kharif", "rabi", "kab"];
    };

    // Tamil — actual UTF-8 characters
    let taKws : KwRow = {
      fertilizer = ["ஆரம்", "உரம்", "யூரியா"];
      disease    = ["நோய்", "நோயாள்", "தீய்மை"];
      pest       = ["பூச்சி", "கீடம்"];
      irrigation = ["நீர்", "தண்ணீர்", "நீர்பாய்ச்சல்"];
      rice       = ["நெல்ல்", "அரிசி"];
      wheat      = ["கோதுமை"];
      cotton     = ["பருத்தி"];
      tomato     = ["தக்காளி"];
      sugarcane  = ["கரும்பு"];
      mango      = ["மாம்பழம்"];
      season     = ["பருவம்", "பயிர்"];
    };

    // Telugu
    let teKws : KwRow = {
      fertilizer = ["ఎరువు", "సేంద్రవం"];
      disease    = ["వ్యాధి", "రోగం", "చెడు"];
      pest       = ["చీడ", "పురుగు", "కీటకం"];
      irrigation = ["నీరు", "నీటి", "సేద్యం"];
      rice       = ["వడ్లు", "బియ్యం"];
      wheat      = ["గోధుమ"];
      cotton     = ["పత్తి"];
      tomato     = ["టొమాటో"];
      sugarcane  = ["చెరకు"];
      mango      = ["మావిడి"];
      season     = ["ఋతువు", "సీజన్"];
    };

    // Kannada
    let knKws : KwRow = {
      fertilizer = ["ಗೊಫ್ಫರ", "ಗೊಫ್ಫರೆ"];
      disease    = ["ರೋಗ", "ಕಾಯಿಲೆ", "ಬಾಧೆ"];
      pest       = ["ಕ್ರಿಮಿ", "ಹುಳು", "ಕೀಟ"];
      irrigation = ["ನೀರಾವರಿ", "ನೀರು", "ತೊರವು"];
      rice       = ["ಭತ್ತ", "ಅಕ್ಕಿ"];
      wheat      = ["ಗೋಧಿ"];
      cotton     = ["ಹತ್ತಿ"];
      tomato     = ["ತಕ್ಕಾಳಿ"];
      sugarcane  = ["ಕಫ್ಫು"];
      mango      = ["ಮಾವಿನಹಣ್ಣು"];
      season     = ["ಋತು", "ಸೀಜನ್"];
    };

    // Malayalam
    let mlKws : KwRow = {
      fertilizer = ["വളം", "കൃഷി വളം"];
      disease    = ["രോഗം", "രോഗബാധ", "കൂണ്"];
      pest       = ["കീട", "പുഴു"];
      irrigation = ["ജലസേചനം", "നനവു", "വെള്ളം"];
      rice       = ["നെല്ല്", "അരി"];
      wheat      = ["ഗോതമ്പ്"];
      cotton     = ["പഞ്ഞ്"];
      tomato     = ["തക്കാളി"];
      sugarcane  = ["കരിമ്പു"];
      mango      = ["മാവ്"];
      season     = ["കാലം", "ഋതു"];
    };

    // Bengali
    let bnKws : KwRow = {
      fertilizer = ["সার", "সারপ্রযোগ"];
      disease    = ["রোগ", "রোগগ্রস্ত"];
      pest       = ["পোকা", "কীট"];
      irrigation = ["সেচ", "সেচাই", "জল"];
      rice       = ["ধান", "চাউল"];
      wheat      = ["গম"];
      cotton     = ["তুলা"];
      tomato     = ["টমেটো"];
      sugarcane  = ["আখ"];
      mango      = ["আম"];
      season     = ["ফসল", "সময়"];
    };

    // Marathi
    let mrKws : KwRow = {
      fertilizer = ["खत", "खते"];
      disease    = ["रोग", "आजार"];
      pest       = ["किडा", "किडे", "कीड"];
      irrigation = ["पाणी", "सिंचन", "वारी"];
      rice       = ["भात", "तांदूळ"];
      wheat      = ["गहू"];
      cotton     = ["कापूस"];
      tomato     = ["टोमेटो"];
      sugarcane  = ["उस"];
      mango      = ["आंबा"];
      season     = ["हंगाम", "वेळ"];
    };

    // Gujarati
    let guKws : KwRow = {
      fertilizer = ["ખાતર", "ખાતરી"];
      disease    = ["રોગ", "બાધા"];
      pest       = ["જીવાત", "કીડો"];
      irrigation = ["સિંચાઈ", "પાણી"];
      rice       = ["ડાંગર", "ભાત"];
      wheat      = ["ઘું", "ઘઉં"];
      cotton     = ["કપાસ"];
      tomato     = ["ટમેતું"];
      sugarcane  = ["શેરડી"];
      mango      = ["કևરી"];
      season     = ["ફસલ", "તરિયા"];
    };

    // Punjabi
    let paKws : KwRow = {
      fertilizer = ["ਖਾਦ", "ખਾਦ"];
      disease    = ["ਬਿਮਾਰੀ", "ਰੋਗ"];
      pest       = ["ਕੀੜਾ", "ਕੀੜੇ", "ਜੰਤ"];
      irrigation = ["ਸਿੰਚਾਈ", "ਪਾਣੀ"];
      rice       = ["ਝੋਨਾ", "ਚਾਵਲ"];
      wheat      = ["ਕਣਕ", "ਕਣਕੂ"];
      cotton     = ["ਨਰਮਾ"];
      tomato     = ["ਟਮਾਟਰ"];
      sugarcane  = ["ਗੰਨਾ"];
      mango      = ["ਆਮ"];
      season     = ["ਮੌਸਮ", "ਜ਼ਰੂਰੀ"];
    };

    // Odia
    let orKws : KwRow = {
      fertilizer = ["ସାର", "ସାର ପ୍ରଯୋଗ"];
      disease    = ["ରୋଗ", "ବ୍ୟାଧି"];
      pest       = ["ପୋକ", "କୀଟ"];
      irrigation = ["ଜଳସେଚନ", "ପାଣି"];
      rice       = ["ଧାନ", "ଚାଉଳ"];
      wheat      = ["ଗହମ"];
      cotton     = ["କପା"];
      tomato     = ["ଟମେଟୋ"];
      sugarcane  = ["ଆଖ"];
      mango      = ["ଆମ"];
      season     = ["ଫସଲ", "ଋତୁ"];
    };

    // Assamese
    let asKws : KwRow = {
      fertilizer = ["সাৰ", "সাৰু"];
      disease    = ["ৰোগ", "ব্যাধি"];
      pest       = ["পোক", "কীট"];
      irrigation = ["জলসিঞ্চন", "পানী"];
      rice       = ["ধান", "চাউল"];
      wheat      = ["ঘেঁহু"];
      cotton     = ["বামোর"];
      tomato     = ["ৰারোল"];
      sugarcane  = ["আখ"];
      mango      = ["আম"];
      season     = ["শস্য", "োর্তু"];
    };

    // Urdu
    let urKws : KwRow = {
      fertilizer = ["کھاد", "زرعی کھاد"];
      disease    = ["بیماری", "علالت"];
      pest       = ["کیڑا", "حشرات"];
      irrigation = ["آبپاشی", "پانی"];
      rice       = ["چاول"];
      wheat      = ["گندم"];
      cotton     = ["کپاس"];
      tomato     = ["ٹماٹر"];
      sugarcane  = ["گنا"];
      mango      = ["آم"];
      season     = ["فصل", "موسم"];
    };

    // Resolve active keyword row by language code
    let activeKws : ?KwRow = switch (language) {
      case "hi" ?hiKws;
      case "ta" ?taKws;
      case "te" ?teKws;
      case "kn" ?knKws;
      case "ml" ?mlKws;
      case "bn" ?bnKws;
      case "mr" ?mrKws;
      case "gu" ?guKws;
      case "pa" ?paKws;
      case "or" ?orKws;
      case "as" ?asKws;
      case "ur" ?urKws;
      case _   null; // "en" or unknown: English-only matching
    };

    // Check a category in a given keyword row
    func matchCat(row : KwRow, cat : Text) : Bool {
      switch (cat) {
        case "fertilizer" anyMatch(q, row.fertilizer);
        case "disease"    anyMatch(q, row.disease);
        case "pest"       anyMatch(q, row.pest);
        case "irrigation" anyMatch(q, row.irrigation);
        case "rice"       anyMatch(q, row.rice);
        case "wheat"      anyMatch(q, row.wheat);
        case "cotton"     anyMatch(q, row.cotton);
        case "tomato"     anyMatch(q, row.tomato);
        case "sugarcane"  anyMatch(q, row.sugarcane);
        case "mango"      anyMatch(q, row.mango);
        case "season"     anyMatch(q, row.season);
        case _            false;
      };
    };

    // Check a category using active language + English fallback
    func check(cat : Text) : Bool {
      let inEn = matchCat(enKws, cat);
      let inLang = switch (activeKws) {
        case (?kws) matchCat(kws, cat);
        case null   false;
      };
      inEn or inLang;
    };

    // Crop flags
    let isRice      = check("rice");
    let isWheat     = check("wheat");
    let isCotton    = check("cotton");
    let isTomato    = check("tomato");
    let isSugarcane = check("sugarcane");
    let isMango     = check("mango");

    // Category flags
    let isFertilizer = check("fertilizer");
    let isDisease    = check("disease");
    let isPest       = check("pest");
    let isWater      = check("irrigation");
    let isSeason     = check("season");

    let (category, answer, relatedCrops) : (AdvisoryTypes.QueryCategory, Text, [Text]) = if (isFertilizer) {
      if (isRice) {
        (#fertilizer, "Rice fertilizer recommendation: Apply NPK 120:60:60 kg/ha. Use Urea for nitrogen, DAP for phosphorus, and MOP for potassium. Split urea into 3 doses: basal (30%), tillering (30%), and panicle initiation (40%). Also apply Zinc Sulphate 25 kg/ha if zinc deficiency is observed.", ["rice"]);
      } else if (isWheat) {
        (#fertilizer, "Wheat fertilizer recommendation: Apply NPK 120:60:40 kg/ha. Apply full P and K at sowing with 50% N. Top-dress remaining N in 2 splits at 21 and 45 days after sowing. Sulfur application (20 kg/ha) improves grain protein quality.", ["wheat"]);
      } else if (isCotton) {
        (#fertilizer, "Cotton fertilizer recommendation: Apply NPK 150:75:75 kg/ha. Apply full P and K with 50% N at planting. Top-dress at squaring and flowering stages. Apply Boron 1-2 kg/ha for boll setting.", ["cotton"]);
      } else if (isTomato) {
        (#fertilizer, "Tomato fertilizer recommendation: Apply NPK 120:80:80 kg/ha. Basal: full P+K+1/3 N. Top-dress in 2 splits. Calcium nitrate foliar spray prevents blossom end rot. Use drip fertigation for best results.", ["tomato"]);
      } else {
        (#fertilizer, "General fertilizer advice: Always do a soil test before applying fertilizers. Follow the NPK ratio recommended for your specific crop. Apply organic matter (FYM/compost) to improve soil health. Use split applications of nitrogen to reduce wastage. Balanced nutrition leads to healthy crops and better yield.", []);
      };
    } else if (isDisease) {
      if (isRice) {
        (#disease, "Rice diseases: Rice blast causes diamond-shaped lesions on leaves - spray Tricyclazole 75% WP at 0.6 g/L. Sheath blight causes pale oval lesions on lower sheaths - spray Hexaconazole 5% SC at 1.5 mL/L. Use resistant varieties and avoid excess nitrogen fertilizer to prevent diseases.", ["rice"]);
      } else if (isWheat) {
        (#disease, "Wheat rust appears as orange-yellow powdery pustules. Spray Propiconazole 25% EC at 0.1% at first sign. Use rust-resistant varieties and timely sowing. Seed treatment with Carboxin + Thiram prevents smut diseases.", ["wheat"]);
      } else if (isTomato) {
        (#disease, "Tomato late blight shows water-soaked patches and rapid wilting. Spray Mancozeb 75% WP at 2.5 g/L every 7 days. Early blight shows target-board spots on older leaves - spray Chlorothalonil. Bacterial wilt has no cure; use resistant varieties and crop rotation.", ["tomato"]);
      } else {
        (#disease, "Common crop diseases are caused by fungi, bacteria, and viruses. Key prevention: use certified seeds, maintain proper spacing, avoid excess nitrogen, ensure good drainage, and practice crop rotation. At first disease sign, identify correctly and use the recommended fungicide/bactericide. Contact your local KVK for expert diagnosis.", []);
      };
    } else if (isPest) {
      if (isCotton) {
        (#pest, "Cotton bollworm control: Install pheromone traps (5/acre) for monitoring. Spray Emamectin Benzoate at 0.4 g/L or Indoxacarb at 0.5 mL/L. Use Bt cotton varieties. Encourage natural enemies like Chrysoperla. Avoid pesticide resistance by rotating chemical groups.", ["cotton"]);
      } else if (isRice) {
        (#pest, "Rice stem borer: Apply Cartap Hydrochloride 4% GR at 18.5 kg/ha in standing water. Monitor with pheromone traps. Release Trichogramma japonicum egg parasitoids. Remove and destroy white ears. Brown Plant Hopper: Drain water and apply Buprofezin 25% SC at 1 mL/L.", ["rice"]);
      } else if (isWheat) {
        (#pest, "Wheat aphid control: Spray Dimethoate 30% EC at 1.5 mL/L or Thiamethoxam 25% WG at 0.3 g/L when 10-15% plants are infested. Aphids also transmit viruses, so early control is important. Natural enemies like ladybird beetles help in biological control.", ["wheat"]);
      } else {
        (#pest, "General pest management: Monitor crops regularly, especially in early growth stages. Use pheromone traps for key pests. Encourage natural enemies (parasitic wasps, predatory beetles). Adopt integrated pest management (IPM): cultural, biological, and chemical methods. Use chemical pesticides only when economic threshold is crossed.", []);
      };
    } else if (isWater) {
      if (isRice) {
        (#irrigation, "Rice water management: Maintain 5 cm standing water during vegetative stage. Alternate wetting and drying (AWD) technique saves 30% water with no yield loss. Drain field 10 days before harvest. Avoid water stress at flowering and grain filling stages.", ["rice"]);
      } else if (isSugarcane) {
        (#irrigation, "Sugarcane irrigation: High water requirement (1500-2500 mm/season). Drip irrigation saves 40-50% water compared to furrow. Critical periods: germination, tillering, grand growth, and maturity. Avoid water stress during grand growth phase (3-9 months after planting).", ["sugarcane"]);
      } else if (isMango) {
        (#irrigation, "Mango irrigation: Mature trees are drought tolerant. Avoid irrigation for 2-3 months before flowering to induce good flowering. Resume after fruit set. Young trees need regular irrigation. Drip irrigation with mulching is most efficient.", ["mango"]);
      } else {
        (#irrigation, "General irrigation guidance: Different crops have different water requirements. High water crops: rice, sugarcane. Medium water crops: wheat, corn, cotton, tomato, potato. Low water crops: mustard, mango. Critical stages for water: germination, flowering, and grain/fruit filling. Drip irrigation increases water use efficiency by 40-60%.", []);
      };
    } else if (isSeason) {
      (#general, "Cropping seasons in India: KHARIF (June-October): Rice, Maize, Cotton, Sugarcane, Soybean, Groundnut - sown at onset of monsoon (June-July). RABI (November-March): Wheat, Mustard, Potato, Onion, Chickpea - sown October-November. ZAID (March-June): Watermelon, Cucumber, Muskmelon, Summer vegetables. YEAR ROUND: Mango, Tomato (multiple seasons), Banana. Local sowing dates vary by region - contact your local KVK for state-specific schedule.", ["rice", "wheat", "corn", "cotton", "mustard"]);
    } else {
      (#general, "Welcome to FarmBuddy! I can help you with: fertilizer recommendations, disease identification, pest control, irrigation guidance, and cropping calendar. For specific advice, mention your crop name (rice, wheat, cotton, tomato, etc.) along with your question. You can also upload a photo of your crop for disease analysis, or browse the crop library for detailed information.", []);
    };
    let id = state.nextQueryId;
    state.nextQueryId += 1;
    let result : AdvisoryTypes.QueryResult = { id; question; answer; category; relatedCrops };
    state.recentQueries.add(result);
    trimRecentQueries(state.recentQueries, 100);
    result;
  };

  // Trims recent queries list to at most maxSize entries (removes from end)
  public func trimRecentQueries(
    queries : List.List<AdvisoryTypes.QueryResult>,
    maxSize : Nat,
  ) : () {
    while (queries.size() > maxSize) {
      ignore queries.removeLast();
    };
  };
};
