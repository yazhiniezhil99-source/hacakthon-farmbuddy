export type {
  Crop,
  DiseaseRecord,
  DiseaseDetectionResult,
  FertilizerRecommendation,
  NPKRatio,
  PhotoUploadResult,
  QueryResult,
  SoilFertilizerMap,
} from "@/backend";

export { QueryCategory, Season, SoilType, WaterNeed } from "@/backend";

export interface NavItem {
  path: string;
  labelKey: import("@/lib/translations").TranslationKey;
  icon: string;
}
