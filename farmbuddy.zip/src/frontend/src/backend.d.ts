import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export class ExternalBlob {
    getBytes(): Promise<Uint8Array<ArrayBuffer>>;
    getDirectURL(): string;
    static fromURL(url: string): ExternalBlob;
    static fromBytes(blob: Uint8Array<ArrayBuffer>): ExternalBlob;
    withUploadProgress(onProgress: (percentage: number) => void): ExternalBlob;
}
export interface SoilFertilizerMap {
    soilType: SoilType;
    recommendation: FertilizerRecommendation;
}
export interface QueryResult {
    id: QueryId;
    question: string;
    relatedCrops: Array<string>;
    answer: string;
    category: QueryCategory;
}
export interface FertilizerRecommendation {
    npkRatio: NPKRatio;
    applicationSchedule: string;
    fertilizerTypes: Array<string>;
    notes: string;
}
export interface Crop {
    id: CropId;
    fertilizerRecommendations: Array<SoilFertilizerMap>;
    growingDurationDays: bigint;
    generalAdvice: string;
    name: string;
    season: Season;
    commonPests: Array<string>;
    waterNeed: WaterNeed;
    localNames: Array<string>;
    soilRequirements: Array<SoilType>;
}
export interface DiseaseRecord {
    id: DiseaseId;
    name: string;
    treatment: string;
    description: string;
    affectedCrops: Array<string>;
    symptoms: Array<string>;
    preventionTips: Array<string>;
}
export interface DiseaseDetectionResult {
    additionalNotes: string;
    disease?: DiseaseRecord;
    confidence: string;
}
export type QueryId = bigint;
export interface PhotoUploadResult {
    blob: ExternalBlob;
    uploadId: bigint;
    detectionResult: DiseaseDetectionResult;
}
export interface NPKRatio {
    potassium: bigint;
    phosphorus: bigint;
    nitrogen: bigint;
}
export type CropId = string;
export type DiseaseId = string;
export enum QueryCategory {
    pest = "pest",
    fertilizer = "fertilizer",
    irrigation = "irrigation",
    disease = "disease",
    general = "general"
}
export enum Season {
    yearRound = "yearRound",
    rabi = "rabi",
    zaid = "zaid",
    kharif = "kharif"
}
export enum SoilType {
    clayey = "clayey",
    saline = "saline",
    sandy = "sandy",
    loamy = "loamy",
    silty = "silty",
    chalky = "chalky",
    peaty = "peaty"
}
export enum WaterNeed {
    low = "low",
    high = "high",
    medium = "medium"
}
export interface backendInterface {
    detectDiseaseFromSymptoms(symptoms: Array<string>): Promise<DiseaseDetectionResult>;
    getCrop(id: CropId): Promise<Crop | null>;
    getFertilizerRecommendation(cropId: CropId, soilType: SoilType): Promise<FertilizerRecommendation | null>;
    getRecentQueries(): Promise<Array<QueryResult>>;
    listCrops(): Promise<Array<Crop>>;
    listCropsBySeason(season: Season): Promise<Array<Crop>>;
    listCropsBySoilType(soilType: SoilType): Promise<Array<Crop>>;
    listDiseases(): Promise<Array<DiseaseRecord>>;
    submitQuery(question: string, language: string): Promise<QueryResult>;
    uploadCropPhoto(blob: ExternalBlob, cropHint: string | null): Promise<PhotoUploadResult>;
}
