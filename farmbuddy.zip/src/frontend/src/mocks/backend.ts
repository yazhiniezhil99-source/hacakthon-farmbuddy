import type { backendInterface, Crop, DiseaseRecord, QueryResult, FertilizerRecommendation, DiseaseDetectionResult, PhotoUploadResult, ExternalBlob } from "../backend";
import { QueryCategory, Season, SoilType, WaterNeed } from "../backend";

const sampleCrop: Crop = {
  id: "rice",
  name: "Rice",
  localNames: ["Chawal", "Dhan", "Arisi", "Bhat", "Akki"],
  season: Season.kharif,
  soilRequirements: [SoilType.loamy, SoilType.clayey, SoilType.silty],
  waterNeed: WaterNeed.high,
  growingDurationDays: BigInt(120),
  commonPests: ["Stem borer", "Brown plant hopper", "Leaf folder", "Rice blast", "Sheath blight"],
  fertilizerRecommendations: [
    {
      soilType: SoilType.loamy,
      recommendation: {
        npkRatio: { nitrogen: BigInt(120), phosphorus: BigInt(60), potassium: BigInt(60) },
        fertilizerTypes: ["Urea", "DAP", "MOP", "Zinc Sulphate"],
        applicationSchedule: "Basal: 30% N + full P + K at transplanting. Top dress: 30% N at tillering, 40% N at panicle initiation.",
        notes: "Apply Zinc Sulphate 25 kg/ha if zinc deficiency is observed. Split urea application reduces nitrogen loss.",
      },
    },
  ],
  generalAdvice: "Maintain 5 cm standing water during vegetative stage. Drain 10 days before harvest. Use certified seeds and practice integrated pest management.",
};

const sampleCrop2: Crop = {
  id: "wheat",
  name: "Wheat",
  localNames: ["Gehun", "Gom", "Godambu", "Godhuma"],
  season: Season.rabi,
  soilRequirements: [SoilType.loamy, SoilType.clayey, SoilType.silty],
  waterNeed: WaterNeed.medium,
  growingDurationDays: BigInt(120),
  commonPests: ["Aphids", "Rust (yellow/brown/black)", "Loose smut", "Karnal bunt", "Termites"],
  fertilizerRecommendations: [
    {
      soilType: SoilType.loamy,
      recommendation: {
        npkRatio: { nitrogen: BigInt(120), phosphorus: BigInt(60), potassium: BigInt(40) },
        fertilizerTypes: ["Urea", "DAP", "MOP"],
        applicationSchedule: "Basal: full P + K + 50% N at sowing. Top dress: 25% N at first irrigation (21 days).",
        notes: "Timely sowing (Nov 1–15) is critical. Apply sulfur 20 kg/ha for quality protein.",
      },
    },
  ],
  generalAdvice: "Use HD-2967 or GW-322 certified seeds. Ensure 6 irrigations at critical growth stages.",
};

const sampleDisease: DiseaseRecord = {
  id: "rice-blast",
  name: "Rice Blast",
  description: "A fungal disease caused by Magnaporthe oryzae that affects rice plants.",
  affectedCrops: ["Rice"],
  symptoms: ["Diamond-shaped lesions on leaves", "Grayish-white center with brown border", "Affected panicles turn whitish"],
  treatment: "Apply Tricyclazole 75WP at 0.6 g/L water. Spray at boot leaf and heading stage.",
  preventionTips: ["Use resistant varieties", "Avoid excess nitrogen", "Maintain proper field drainage"],
};

const sampleDisease2: DiseaseRecord = {
  id: "late-blight",
  name: "Late Blight",
  description: "A serious disease caused by Phytophthora infestans affecting tomato and potato.",
  affectedCrops: ["Tomato", "Potato"],
  symptoms: ["Water-soaked lesions on leaves", "White mold on leaf undersides", "Dark brown lesions on stems"],
  treatment: "Apply Mancozeb 75WP at 2.5 g/L or Metalaxyl+Mancozeb at 2 g/L water.",
  preventionTips: ["Grow resistant varieties", "Avoid overhead irrigation", "Remove infected plant material"],
};

const sampleDetectionResult: DiseaseDetectionResult = {
  disease: sampleDisease,
  confidence: "High (85%)",
  additionalNotes: "Based on the symptoms, this appears to be Rice Blast. Please consult your local agricultural officer for confirmation.",
};

const sampleQuery: QueryResult = {
  id: BigInt(1),
  question: "How much water does rice need?",
  answer: "Rice requires high water throughout its growing period. Maintain 5 cm standing water during vegetative stage. Drain 10 days before harvest.",
  relatedCrops: ["Rice"],
  category: QueryCategory.irrigation,
};

const sampleFertilizer: FertilizerRecommendation = {
  npkRatio: { nitrogen: BigInt(120), phosphorus: BigInt(60), potassium: BigInt(60) },
  fertilizerTypes: ["Urea", "DAP", "MOP", "Zinc Sulphate"],
  applicationSchedule: "Basal: 30% N + full P + K at transplanting. Top dress: 30% N at tillering, 40% N at panicle initiation.",
  notes: "Apply Zinc Sulphate 25 kg/ha if zinc deficiency is observed.",
};

export const mockBackend: backendInterface = {
  listCrops: async () => [sampleCrop, sampleCrop2],
  listCropsBySeason: async (_season) => [sampleCrop],
  listCropsBySoilType: async (_soilType) => [sampleCrop, sampleCrop2],
  getCrop: async (id) => (id === "rice" ? sampleCrop : null),
  getFertilizerRecommendation: async (_cropId, _soilType) => sampleFertilizer,
  listDiseases: async () => [sampleDisease, sampleDisease2],
  detectDiseaseFromSymptoms: async (_symptoms) => sampleDetectionResult,
  submitQuery: async (question) => ({ ...sampleQuery, question }),
  getRecentQueries: async () => [sampleQuery],
  uploadCropPhoto: async (_blob, _cropHint) => ({
    blob: _blob,
    uploadId: BigInt(1),
    detectionResult: sampleDetectionResult,
  } as PhotoUploadResult),
  _immutableObjectStorageBlobsAreLive: async (_hashes) => [],
  _immutableObjectStorageBlobsToDelete: async () => [],
  _immutableObjectStorageConfirmBlobDeletion: async (_blobs) => undefined,
  _immutableObjectStorageCreateCertificate: async (_hash) => ({ ok: null } as never),
  _immutableObjectStorageRefillCashier: async (_info) => ({ ok: null } as never),
  _immutableObjectStorageUpdateGatewayPrincipals: async () => undefined,
};
