import { LanguageSelector } from "@/components/LanguageSelector";
import { Layout } from "@/components/Layout";
import { LanguageProvider, useLanguage } from "@/contexts/LanguageContext";
import {
  Navigate,
  Outlet,
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import React, { Suspense, lazy } from "react";

const HomePage = lazy(() => import("@/pages/HomePage"));
const QueryPage = lazy(() => import("@/pages/QueryPage"));
const UploadPage = lazy(() => import("@/pages/UploadPage"));
const CropsPage = lazy(() => import("@/pages/CropsPage"));
const SettingsPage = lazy(() => import("@/pages/SettingsPage"));

function PageLoader() {
  return (
    <div className="flex items-center justify-center min-h-[40vh]">
      <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
    </div>
  );
}

function AppGuard() {
  const { hasSelectedLanguage } = useLanguage();
  const [showSelector, setShowSelector] = React.useState(!hasSelectedLanguage);

  if (showSelector) {
    return <LanguageSelector onSelect={() => setShowSelector(false)} />;
  }

  return (
    <Layout>
      <Suspense fallback={<PageLoader />}>
        <Outlet />
      </Suspense>
    </Layout>
  );
}

const rootRoute = createRootRoute({ component: AppGuard });

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: () => <Navigate to="/home" />,
});

const homeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/home",
  component: HomePage,
});

const queryRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/query",
  component: QueryPage,
});

const uploadRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/upload",
  component: UploadPage,
});

const cropsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/crops",
  component: CropsPage,
});

const settingsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/settings",
  component: SettingsPage,
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  homeRoute,
  queryRoute,
  uploadRoute,
  cropsRoute,
  settingsRoute,
]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return (
    <LanguageProvider>
      <RouterProvider router={router} />
    </LanguageProvider>
  );
}
