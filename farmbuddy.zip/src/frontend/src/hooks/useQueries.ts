import { createActor } from "@/backend";
import type { ExternalBlob } from "@/backend";
import type {
  Crop,
  DiseaseRecord,
  FertilizerRecommendation,
  PhotoUploadResult,
  QueryResult,
} from "@/types";
import type { Season, SoilType } from "@/types";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export function useListCrops() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Crop[]>({
    queryKey: ["crops"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.listCrops();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useListCropsBySeason(season: Season) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Crop[]>({
    queryKey: ["crops", "season", season],
    queryFn: async () => {
      if (!actor) return [];
      return actor.listCropsBySeason(season);
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetCrop(id: string) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Crop | null>({
    queryKey: ["crop", id],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getCrop(id);
    },
    enabled: !!actor && !isFetching && !!id,
  });
}

export function useGetFertilizerRecommendation(
  cropId: string,
  soilType: SoilType,
) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<FertilizerRecommendation | null>({
    queryKey: ["fertilizer", cropId, soilType],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getFertilizerRecommendation(cropId, soilType);
    },
    enabled: !!actor && !isFetching && !!cropId,
  });
}

export function useListDiseases() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<DiseaseRecord[]>({
    queryKey: ["diseases"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.listDiseases();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useRecentQueries() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<QueryResult[]>({
    queryKey: ["queries", "recent"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getRecentQueries();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSubmitQuery() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation<
    QueryResult,
    Error,
    { question: string; language: string }
  >({
    mutationFn: async ({ question, language }) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.submitQuery(question, language);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["queries", "recent"] });
    },
  });
}

export function useUploadCropPhoto() {
  const { actor } = useActor(createActor);
  return useMutation<
    PhotoUploadResult,
    Error,
    { blob: ExternalBlob; cropHint: string | null }
  >({
    mutationFn: async ({ blob, cropHint }) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.uploadCropPhoto(blob, cropHint);
    },
  });
}

export function useDetectDiseaseFromSymptoms() {
  const { actor } = useActor(createActor);
  return useMutation({
    mutationFn: async (symptoms: string[]) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.detectDiseaseFromSymptoms(symptoms);
    },
  });
}
