import { useLanguage } from "@/contexts/LanguageContext";
import {
  useGetFertilizerRecommendation,
  useListCrops,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { Crop } from "@/types";
import { Season, SoilType, WaterNeed } from "@/types";
import { ChevronRight, Clock, Droplets, Search, Sprout, X } from "lucide-react";
import { motion } from "motion/react";
import React, { useState } from "react";

const seasonColors: Record<Season, string> = {
  [Season.kharif]: "bg-primary/10 text-primary",
  [Season.rabi]: "bg-secondary/10 text-secondary",
  [Season.zaid]: "bg-accent/20 text-accent-foreground",
  [Season.yearRound]: "bg-muted text-muted-foreground",
};

const waterColors: Record<WaterNeed, string> = {
  [WaterNeed.low]: "text-secondary",
  [WaterNeed.medium]: "text-accent-foreground",
  [WaterNeed.high]: "text-primary",
};

function CropDetailSheet({
  crop,
  onClose,
}: { crop: Crop; onClose: () => void }) {
  const { t } = useLanguage();
  const [selectedSoil, setSelectedSoil] = useState<SoilType>(SoilType.loamy);
  const { data: fertRec } = useGetFertilizerRecommendation(
    crop.id,
    selectedSoil,
  );

  return (
    // biome-ignore lint/a11y/useKeyWithClickEvents: overlay backdrop dismiss
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-foreground/40 backdrop-blur-sm"
      onClick={onClose}
      data-ocid="crop_detail.dialog"
    >
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 40 }}
        className="bg-card rounded-t-2xl sm:rounded-2xl w-full sm:max-w-lg max-h-[85vh] overflow-y-auto shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-card border-b border-border px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sprout className="w-5 h-5 text-primary" />
            <h3 className="font-display font-bold text-base text-foreground">
              {crop.name}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            data-ocid="crop_detail.close_button"
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-muted transition-smooth"
            aria-label={t("close")}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-4 py-4 space-y-4">
          {crop.localNames.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {crop.localNames.map((n) => (
                <span
                  key={n}
                  className="px-2.5 py-1 bg-muted text-muted-foreground text-xs rounded-full"
                >
                  {n}
                </span>
              ))}
            </div>
          )}

          <div className="grid grid-cols-3 gap-2">
            <div className="bg-muted/50 rounded-xl p-3 text-center">
              <p className="text-xs text-muted-foreground mb-1">
                {t("season")}
              </p>
              <span
                className={cn(
                  "text-xs font-semibold px-2 py-0.5 rounded-full",
                  seasonColors[crop.season],
                )}
              >
                {t(crop.season as TranslationKey)}
              </span>
            </div>
            <div className="bg-muted/50 rounded-xl p-3 text-center">
              <Droplets
                className={cn(
                  "w-4 h-4 mx-auto mb-1",
                  waterColors[crop.waterNeed],
                )}
              />
              <p className="text-xs text-muted-foreground">{t("waterNeed")}</p>
              <p className="text-xs font-semibold text-foreground">
                {t(crop.waterNeed as TranslationKey)}
              </p>
            </div>
            <div className="bg-muted/50 rounded-xl p-3 text-center">
              <Clock className="w-4 h-4 mx-auto mb-1 text-accent-foreground" />
              <p className="text-xs text-muted-foreground">{t("duration")}</p>
              <p className="text-xs font-semibold text-foreground">
                {crop.growingDurationDays.toString()} {t("days")}
              </p>
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              {t("advice")}
            </p>
            <p className="text-sm text-foreground leading-relaxed">
              {crop.generalAdvice}
            </p>
          </div>

          {crop.commonPests.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
                {t("pestInfo")}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {crop.commonPests.map((p) => (
                  <span
                    key={p}
                    className="px-2.5 py-1 bg-destructive/10 text-destructive text-xs rounded-full"
                  >
                    {p}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Fertilizer */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              {t("fertilizer")}
            </p>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {Object.values(SoilType).map((soil) => (
                <button
                  key={soil}
                  type="button"
                  onClick={() => setSelectedSoil(soil)}
                  className={cn(
                    "px-2.5 py-1 text-xs rounded-full border transition-smooth",
                    selectedSoil === soil
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-border text-muted-foreground hover:border-primary/40",
                  )}
                >
                  {soil}
                </button>
              ))}
            </div>
            {fertRec ? (
              <div className="bg-muted/30 rounded-xl p-3 space-y-1.5">
                <p className="text-sm text-foreground">
                  <span className="font-semibold">{t("npkRatio")}: </span>
                  {fertRec.npkRatio.nitrogen.toString()}-
                  {fertRec.npkRatio.phosphorus.toString()}-
                  {fertRec.npkRatio.potassium.toString()}
                </p>
                <p className="text-sm text-foreground">
                  <span className="font-semibold">
                    {t("applicationSchedule")}:{" "}
                  </span>
                  {fertRec.applicationSchedule}
                </p>
                {fertRec.fertilizerTypes.length > 0 && (
                  <p className="text-xs text-muted-foreground">
                    {fertRec.fertilizerTypes.join(", ")}
                  </p>
                )}
                {fertRec.notes && (
                  <p className="text-xs text-muted-foreground">
                    {fertRec.notes}
                  </p>
                )}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">{t("loading")}</p>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function CropsPage() {
  const { t } = useLanguage();
  const [search, setSearch] = useState("");
  const [selectedCrop, setSelectedCrop] = useState<Crop | null>(null);
  const [seasonFilter, setSeasonFilter] = useState<Season | "all">("all");
  const { data: crops, isLoading } = useListCrops();

  const filtered = (crops ?? []).filter((c) => {
    const matchSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.localNames.some((n) => n.toLowerCase().includes(search.toLowerCase()));
    const matchSeason = seasonFilter === "all" || c.season === seasonFilter;
    return matchSearch && matchSeason;
  });

  return (
    <div className="flex flex-col min-h-full">
      {/* Search */}
      <div className="bg-card border-b border-border px-4 py-4">
        <h2 className="font-display font-bold text-lg text-foreground mb-3">
          {t("cropLibrary")}
        </h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("searchCrops")}
            data-ocid="crops.search_input"
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-input bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        {/* Season filter */}
        <div
          className="flex gap-2 mt-3 overflow-x-auto pb-0.5"
          data-ocid="crops.season_filter"
        >
          <button
            type="button"
            onClick={() => setSeasonFilter("all")}
            data-ocid="crops.season.all"
            className={cn(
              "px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-smooth touch-target",
              seasonFilter === "all"
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80",
            )}
          >
            {t("all")}
          </button>
          {Object.values(Season).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSeasonFilter(s)}
              data-ocid={`crops.season.${s}`}
              className={cn(
                "px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-smooth touch-target",
                seasonFilter === s
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80",
              )}
            >
              {t(s as TranslationKey)}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      <div className="px-4 py-4">
        {isLoading ? (
          <div className="space-y-3" data-ocid="crops.loading_state">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-16 bg-muted animate-pulse rounded-xl" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12" data-ocid="crops.empty_state">
            <Sprout className="w-10 h-10 text-muted-foreground/50 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              {search ? t("noCropsFound") : t("loading")}
            </p>
          </div>
        ) : (
          <div className="space-y-2" data-ocid="crops.list">
            {filtered.map((crop, i) => (
              <motion.button
                key={crop.id}
                type="button"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04, duration: 0.2 }}
                onClick={() => setSelectedCrop(crop)}
                data-ocid={`crops.item.${i + 1}`}
                className="w-full bg-card border border-border rounded-xl p-3 flex items-center gap-3 hover:border-primary/30 hover:shadow-sm active:scale-[0.99] transition-smooth text-left"
              >
                <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
                  <Sprout className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display font-semibold text-sm text-foreground">
                    {crop.name}
                  </p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span
                      className={cn(
                        "text-[11px] px-2 py-0.5 rounded-full font-medium",
                        seasonColors[crop.season],
                      )}
                    >
                      {t(crop.season as TranslationKey)}
                    </span>
                    <span className="text-[11px] text-muted-foreground">
                      {crop.growingDurationDays.toString()} {t("days")}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
              </motion.button>
            ))}
          </div>
        )}
      </div>

      {/* Detail Sheet */}
      {selectedCrop && (
        <CropDetailSheet
          crop={selectedCrop}
          onClose={() => setSelectedCrop(null)}
        />
      )}
    </div>
  );
}

type TranslationKey = import("@/lib/translations").TranslationKey;
