import { LANGUAGES, useLanguage } from "@/contexts/LanguageContext";
import type { LanguageCode } from "@/lib/translations";
import { cn } from "@/lib/utils";
import { ChevronRight, Globe, Info, Leaf } from "lucide-react";
import { motion } from "motion/react";
import React from "react";

export default function SettingsPage() {
  const { t, language, setLanguage } = useLanguage();

  return (
    <div className="flex flex-col min-h-full">
      <div className="bg-card border-b border-border px-4 py-5">
        <h2 className="font-display font-bold text-lg text-foreground">
          {t("settings")}
        </h2>
      </div>

      <div className="px-4 py-5 space-y-5">
        {/* Current language */}
        <div className="bg-card rounded-2xl border border-border p-4">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-5 h-5 text-primary" />
            <p className="font-display font-semibold text-sm text-foreground">
              {t("changeLanguage")}
            </p>
          </div>
          <div
            className="grid grid-cols-2 gap-2.5"
            data-ocid="settings.language_list"
          >
            {LANGUAGES.map((lang, i) => (
              <motion.button
                key={lang.code}
                type="button"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.03 }}
                onClick={() => setLanguage(lang.code as LanguageCode)}
                data-ocid={`settings.language.${lang.code}`}
                className={cn(
                  "flex items-center gap-2.5 p-3 rounded-xl border-2 transition-smooth touch-target text-left",
                  language === lang.code
                    ? "border-primary bg-primary/10"
                    : "border-border hover:border-primary/30 hover:bg-muted",
                )}
              >
                <span className="text-lg">{lang.flag}</span>
                <div className="flex-1 min-w-0">
                  <p
                    className={cn(
                      "font-display font-semibold text-xs leading-tight truncate",
                      language === lang.code
                        ? "text-primary"
                        : "text-foreground",
                    )}
                  >
                    {lang.nativeName}
                  </p>
                  <p className="text-[10px] text-muted-foreground truncate">
                    {lang.name}
                  </p>
                </div>
                {language === lang.code && (
                  <span className="w-4 h-4 rounded-full bg-primary flex items-center justify-center text-[8px] text-primary-foreground font-bold shrink-0">
                    ✓
                  </span>
                )}
              </motion.button>
            ))}
          </div>
        </div>

        {/* About */}
        <div className="bg-card rounded-2xl border border-border p-4">
          <div className="flex items-center gap-3 mb-3">
            <Leaf className="w-5 h-5 text-primary" />
            <p className="font-display font-semibold text-sm text-foreground">
              {t("appName")}
            </p>
          </div>
          <div className="space-y-2">
            <div className="flex items-start gap-2 p-3 bg-muted/40 rounded-xl">
              <Info className="w-4 h-4 text-primary mt-0.5 shrink-0" />
              <p className="text-xs text-muted-foreground leading-relaxed">
                FarmBuddy is a free AI-powered advisory platform for Indian
                farmers. Get crop guidance, fertilizer recommendations, and
                disease detection — all in your local language.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground pb-2">
          &copy; {new Date().getFullYear()}. Built with love using{" "}
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
            target="_blank"
            rel="noreferrer"
            className="underline hover:text-foreground transition-colors"
          >
            caffeine.ai
          </a>
        </p>
      </div>
    </div>
  );
}
