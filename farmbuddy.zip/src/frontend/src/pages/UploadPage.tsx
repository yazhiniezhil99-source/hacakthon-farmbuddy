import { ExternalBlob } from "@/backend";
import { useLanguage } from "@/contexts/LanguageContext";
import { useUploadCropPhoto } from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { PhotoUploadResult } from "@/types";
import {
  AlertTriangle,
  Camera,
  CheckCircle,
  Loader2,
  Upload,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import type React from "react";
import { useRef, useState } from "react";

export default function UploadPage() {
  const { t } = useLanguage();
  const [preview, setPreview] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<PhotoUploadResult | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const { mutate: upload, isPending, error } = useUploadCropPhoto();

  function handleFile(f: File) {
    setFile(f);
    setResult(null);
    const reader = new FileReader();
    reader.onload = (e) => setPreview(e.target?.result as string);
    reader.readAsDataURL(f);
  }

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (f) handleFile(f);
  }

  async function handleAnalyze() {
    if (!file) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    const blob = ExternalBlob.fromBytes(bytes);
    upload(
      { blob, cropHint: null },
      {
        onSuccess: (res) => setResult(res),
      },
    );
  }

  function handleReset() {
    setPreview(null);
    setFile(null);
    setResult(null);
    if (fileRef.current) fileRef.current.value = "";
    if (cameraRef.current) cameraRef.current.value = "";
  }

  const { detectionResult } = result ?? {};
  const hasDisease = detectionResult?.disease != null;

  return (
    <div className="flex flex-col min-h-full">
      <div className="bg-card border-b border-border px-4 py-5">
        <h2 className="font-display font-bold text-lg text-foreground">
          {t("uploadCropPhoto")}
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          {t("uploadInstruction")}
        </p>
      </div>

      <div className="px-4 py-5 flex flex-col gap-4">
        {/* Upload zone */}
        {!preview ? (
          <div
            className="rounded-2xl border-2 border-dashed border-border bg-muted/30 flex flex-col items-center justify-center gap-4 py-12 px-4"
            data-ocid="upload.dropzone"
          >
            <div className="w-16 h-16 bg-card border border-border rounded-2xl flex items-center justify-center">
              <Upload className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground text-center max-w-[200px]">
              {t("uploadInstruction")}
            </p>
            <div className="flex gap-3 mt-1">
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleInputChange}
              />
              <input
                ref={cameraRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleInputChange}
              />
              <button
                type="button"
                onClick={() => cameraRef.current?.click()}
                data-ocid="upload.camera_button"
                className="flex items-center gap-2 px-4 py-3 bg-primary text-primary-foreground text-sm font-medium rounded-xl touch-target"
              >
                <Camera className="w-4 h-4" />
                {t("camera")}
              </button>
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                data-ocid="upload.upload_button"
                className="flex items-center gap-2 px-4 py-3 bg-card border border-border text-foreground text-sm font-medium rounded-xl touch-target hover:bg-muted transition-smooth"
              >
                <Upload className="w-4 h-4" />
                {t("upload")}
              </button>
            </div>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative rounded-2xl overflow-hidden bg-card border border-border"
          >
            <img
              src={preview}
              alt="Crop preview"
              className="w-full aspect-[4/3] object-cover"
              data-ocid="upload.preview"
            />
            <button
              type="button"
              onClick={handleReset}
              data-ocid="upload.reset_button"
              className="absolute top-2 right-2 w-8 h-8 bg-foreground/70 text-background rounded-full flex items-center justify-center"
              aria-label={t("clear")}
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}

        {/* Analyze button */}
        {preview && !result && (
          <motion.button
            type="button"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={handleAnalyze}
            disabled={isPending}
            data-ocid="upload.analyze_button"
            className="w-full py-4 bg-primary text-primary-foreground font-display font-bold text-base rounded-2xl flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-60 transition-smooth touch-target"
          >
            {isPending ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                {t("analyzing")}
              </>
            ) : (
              <>
                <Camera className="w-5 h-5" />
                {t("submit")}
              </>
            )}
          </motion.button>
        )}

        {/* Error */}
        {error && (
          <div
            className="flex items-center gap-2 p-3 bg-destructive/10 text-destructive rounded-xl text-sm"
            data-ocid="upload.error_state"
          >
            <AlertTriangle className="w-4 h-4 shrink-0" />
            {t("error")}
          </div>
        )}

        {/* Detection Result */}
        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-2xl border border-border overflow-hidden"
              data-ocid="upload.detection_result"
            >
              <div
                className={cn(
                  "px-4 py-3 flex items-center gap-3",
                  hasDisease ? "bg-destructive/10" : "bg-primary/10",
                )}
              >
                {hasDisease ? (
                  <AlertTriangle className="w-5 h-5 text-destructive" />
                ) : (
                  <CheckCircle className="w-5 h-5 text-primary" />
                )}
                <div>
                  <p
                    className={cn(
                      "font-display font-bold text-sm",
                      hasDisease ? "text-destructive" : "text-primary",
                    )}
                  >
                    {hasDisease ? t("diseaseDetected") : t("noDisease")}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {t("confidence")}: {detectionResult?.confidence}
                  </p>
                </div>
              </div>

              {hasDisease && detectionResult?.disease && (
                <div className="px-4 py-4 space-y-3">
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                      {t("detectionResult")}
                    </p>
                    <p className="text-base font-display font-bold text-foreground">
                      {detectionResult.disease.name}
                    </p>
                    <p className="text-sm text-muted-foreground mt-0.5">
                      {detectionResult.disease.description}
                    </p>
                  </div>
                  {detectionResult.disease.symptoms.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                        {t("symptoms")}
                      </p>
                      <ul className="space-y-1">
                        {detectionResult.disease.symptoms.map((s) => (
                          <li
                            key={s}
                            className="text-sm text-foreground flex items-start gap-1.5"
                          >
                            <span className="text-destructive mt-1">•</span>
                            {s}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                      {t("treatment")}
                    </p>
                    <p className="text-sm text-foreground">
                      {detectionResult.disease.treatment}
                    </p>
                  </div>
                  {detectionResult.disease.preventionTips.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                        {t("prevention")}
                      </p>
                      <ul className="space-y-1">
                        {detectionResult.disease.preventionTips.map((tip) => (
                          <li
                            key={tip}
                            className="text-sm text-foreground flex items-start gap-1.5"
                          >
                            <span className="text-primary mt-1">•</span>
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {detectionResult.additionalNotes && (
                    <p className="text-xs text-muted-foreground border-t border-border pt-3">
                      {detectionResult.additionalNotes}
                    </p>
                  )}
                </div>
              )}

              {!hasDisease && detectionResult?.additionalNotes && (
                <p className="px-4 py-3 text-sm text-muted-foreground">
                  {detectionResult.additionalNotes}
                </p>
              )}

              <div className="px-4 pb-4">
                <button
                  type="button"
                  onClick={handleReset}
                  data-ocid="upload.new_photo_button"
                  className="w-full py-3 border border-border rounded-xl text-sm font-medium text-muted-foreground hover:bg-muted transition-smooth touch-target"
                >
                  {t("clear")}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
