import { useLanguage } from "@/contexts/LanguageContext";
import { useRecentQueries } from "@/hooks/useQueries";
import type { TranslationKey } from "@/lib/translations";
import { cn } from "@/lib/utils";
import { Link } from "@tanstack/react-router";
import {
  Camera,
  ChevronRight,
  Clock,
  Globe,
  Leaf,
  MessageCircle,
  Sprout,
} from "lucide-react";
import { motion } from "motion/react";
import type React from "react";

const quickActions: Array<{
  path: string;
  labelKey: TranslationKey;
  subKey: TranslationKey;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bg: string;
}> = [
  {
    path: "/query",
    labelKey: "askQuestion",
    subKey: "typeQuestion",
    icon: MessageCircle,
    color: "text-primary",
    bg: "bg-primary/10",
  },
  {
    path: "/upload",
    labelKey: "uploadPhoto",
    subKey: "uploadInstruction",
    icon: Camera,
    color: "text-secondary",
    bg: "bg-secondary/10",
  },
  {
    path: "/crops",
    labelKey: "browseCrops",
    subKey: "cropLibrary",
    icon: Sprout,
    color: "text-accent",
    bg: "bg-accent/10",
  },
  {
    path: "/settings",
    labelKey: "languageSettings",
    subKey: "changeLanguage",
    icon: Globe,
    color: "text-muted-foreground",
    bg: "bg-muted",
  },
];

export default function HomePage() {
  const { t } = useLanguage();
  const { data: recentQueries, isLoading } = useRecentQueries();

  return (
    <div className="flex flex-col min-h-full">
      {/* Hero banner */}
      <div className="relative overflow-hidden bg-primary px-5 py-8">
        <img
          src="/assets/generated/farmbuddy-hero.dim_800x500.jpg"
          alt="FarmBuddy farming illustration"
          className="absolute inset-0 w-full h-full object-cover opacity-20"
        />
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="relative z-10"
        >
          <div className="flex items-center gap-2 mb-2">
            <Leaf className="w-6 h-6 text-primary-foreground/80" />
            <span className="text-primary-foreground/80 text-sm font-display">
              {t("appName")}
            </span>
          </div>
          <h2 className="font-display font-bold text-2xl text-primary-foreground leading-tight">
            {t("welcomeTitle")}
          </h2>
          <p className="text-primary-foreground/75 text-sm mt-1">
            {t("welcomeSubtitle")}
          </p>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-5 bg-background">
        <div className="grid grid-cols-2 gap-3">
          {quickActions.map(
            ({ path, labelKey, subKey, icon: Icon, color, bg }, i) => (
              <motion.div
                key={path}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.1 + i * 0.08 }}
              >
                <Link
                  to={path}
                  data-ocid={`home.action.${labelKey}`}
                  className="flex flex-col gap-3 p-4 bg-card rounded-2xl border border-border shadow-xs hover:shadow-md hover:border-primary/30 active:scale-95 transition-smooth min-h-[110px]"
                >
                  <div
                    className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center",
                      bg,
                    )}
                  >
                    <Icon className={cn("w-6 h-6", color)} />
                  </div>
                  <div>
                    <p className="font-display font-semibold text-sm text-foreground leading-tight">
                      {t(labelKey)}
                    </p>
                    <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-1">
                      {t(subKey)}
                    </p>
                  </div>
                </Link>
              </motion.div>
            ),
          )}
        </div>
      </div>

      {/* Recent Queries */}
      <div className="px-4 pb-6 bg-muted/30">
        <div className="flex items-center gap-2 mb-3 pt-4">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <h3 className="font-display font-semibold text-sm text-foreground">
            {t("recentQueries")}
          </h3>
        </div>

        {isLoading ? (
          <div className="space-y-2" data-ocid="home.queries.loading_state">
            {[1, 2].map((i) => (
              <div key={i} className="h-14 bg-muted animate-pulse rounded-xl" />
            ))}
          </div>
        ) : recentQueries && recentQueries.length > 0 ? (
          <div className="space-y-2" data-ocid="home.queries.list">
            {recentQueries.slice(0, 5).map((q, idx) => (
              <motion.div
                key={q.id.toString()}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.06 }}
                data-ocid={`home.queries.item.${idx + 1}`}
                className="bg-card rounded-xl border border-border p-3 flex items-start gap-3 shadow-xs"
              >
                <MessageCircle className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground font-medium truncate">
                    {q.question}
                  </p>
                  <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
                    {q.answer}
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
              </motion.div>
            ))}
          </div>
        ) : (
          <div
            className="text-center py-8"
            data-ocid="home.queries.empty_state"
          >
            <MessageCircle className="w-8 h-8 text-muted-foreground/50 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              {t("noRecentQueries")}
            </p>
            <Link
              to="/query"
              data-ocid="home.queries.ask_button"
              className="inline-flex items-center gap-1.5 mt-3 px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-xl touch-target"
            >
              {t("askQuestion")}
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
