import { useLanguage } from "@/contexts/LanguageContext";
import { useRecentQueries, useSubmitQuery } from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { QueryResult } from "@/types";
import { QueryCategory } from "@/types";
import { ChevronRight, Mic, MicOff, Send, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import React, { useRef, useState } from "react";

const categoryColors: Record<QueryCategory, string> = {
  [QueryCategory.disease]: "bg-destructive/10 text-destructive",
  [QueryCategory.pest]: "bg-accent/20 text-accent-foreground",
  [QueryCategory.fertilizer]: "bg-secondary/20 text-secondary",
  [QueryCategory.irrigation]: "bg-primary/10 text-primary",
  [QueryCategory.general]: "bg-muted text-muted-foreground",
};

export default function QueryPage() {
  const { t, language } = useLanguage();
  const [question, setQuestion] = useState("");
  const [result, setResult] = useState<QueryResult | null>(null);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<{ stop: () => void } | null>(null);
  const { mutate: submitQuery, isPending } = useSubmitQuery();
  const { data: recent } = useRecentQueries();

  function handleSubmit() {
    if (!question.trim()) return;
    submitQuery(
      { question: question.trim(), language },
      {
        onSuccess: (res) => {
          setResult(res);
          setQuestion("");
        },
      },
    );
  }

  function handleVoice() {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SR =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (!SR) return;

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const recognition: any = new SR();
    recognitionRef.current = recognition;
    const langMap: Record<string, string> = {
      hi: "hi-IN",
      ta: "ta-IN",
      te: "te-IN",
      kn: "kn-IN",
      ml: "ml-IN",
      bn: "bn-IN",
      mr: "mr-IN",
      gu: "gu-IN",
      pa: "pa-IN",
      or: "or-IN",
      as: "as-IN",
      ur: "ur-PK",
      en: "en-IN",
    };
    recognition.lang = langMap[language] ?? "hi-IN";
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onresult = (e: any) => {
      setQuestion((q) => `${q} ${e.results[0][0].transcript}`);
    };
    recognition.start();
  }

  return (
    <div className="flex flex-col min-h-full">
      {/* Input zone */}
      <div className="bg-card border-b border-border px-4 py-5">
        <h2 className="font-display font-bold text-lg text-foreground mb-3">
          {t("askQuestion")}
        </h2>
        <div className="relative">
          <textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder={t("typeQuestion")}
            rows={3}
            data-ocid="query.input"
            className="w-full resize-none rounded-xl border border-input bg-background px-4 py-3 text-base text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring pr-12 font-body"
          />
          <button
            type="button"
            onClick={handleVoice}
            data-ocid="query.voice_button"
            aria-label={t("voiceInput")}
            className={cn(
              "absolute right-3 bottom-3 w-8 h-8 rounded-lg flex items-center justify-center transition-smooth",
              isListening
                ? "bg-destructive text-destructive-foreground animate-pulse"
                : "bg-muted text-muted-foreground hover:bg-primary hover:text-primary-foreground",
            )}
          >
            {isListening ? (
              <MicOff className="w-4 h-4" />
            ) : (
              <Mic className="w-4 h-4" />
            )}
          </button>
        </div>
        <div className="flex gap-2 mt-3">
          <button
            type="button"
            onClick={() => setQuestion("")}
            data-ocid="query.clear_button"
            className="flex-1 py-3 rounded-xl border border-border text-sm font-medium text-muted-foreground hover:bg-muted transition-smooth touch-target"
          >
            {t("clear")}
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!question.trim() || isPending}
            data-ocid="query.submit_button"
            className="flex-[2] py-3 rounded-xl bg-primary text-primary-foreground text-sm font-bold font-display flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-50 transition-smooth touch-target"
          >
            {isPending ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                {t("loading")}
              </span>
            ) : (
              <>
                <Send className="w-4 h-4" />
                {t("submit")}
              </>
            )}
          </button>
        </div>
      </div>

      {/* Result */}
      <AnimatePresence mode="wait">
        {result && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mx-4 mt-4 bg-card rounded-2xl border border-border p-4 shadow-sm"
            data-ocid="query.result"
          >
            <div className="flex items-start justify-between gap-2 mb-2">
              <span
                className={cn(
                  "px-2 py-0.5 rounded-full text-[11px] font-medium",
                  categoryColors[result.category],
                )}
              >
                {t(result.category as TranslationKey)}
              </span>
              <button
                type="button"
                onClick={() => setResult(null)}
                data-ocid="query.close_button"
                className="text-muted-foreground hover:text-foreground p-1"
                aria-label={t("close")}
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-muted-foreground mb-1 font-medium">
              {result.question}
            </p>
            <p className="text-sm text-foreground leading-relaxed">
              {result.answer}
            </p>
            {result.relatedCrops.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {result.relatedCrops.map((crop) => (
                  <span
                    key={crop}
                    className="px-2 py-0.5 bg-primary/10 text-primary rounded-full text-[11px] font-medium"
                  >
                    {crop}
                  </span>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Recent */}
      {recent && recent.length > 0 && (
        <div className="px-4 py-5">
          <h3 className="font-display font-semibold text-sm text-foreground mb-3">
            {t("recentQueries")}
          </h3>
          <div className="space-y-2" data-ocid="query.recent.list">
            {recent.slice(0, 5).map((q, i) => (
              <button
                key={q.id.toString()}
                type="button"
                onClick={() => setResult(q)}
                data-ocid={`query.recent.item.${i + 1}`}
                className="w-full text-left bg-card border border-border rounded-xl p-3 flex items-center gap-3 hover:border-primary/30 hover:shadow-sm transition-smooth"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {q.question}
                  </p>
                  <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
                    {q.answer}
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

type TranslationKey = import("@/lib/translations").TranslationKey;
