// Bottom navigation is embedded in Layout.tsx
export {};
