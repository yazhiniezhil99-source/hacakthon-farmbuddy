import { LANGUAGES, useLanguage } from "@/contexts/LanguageContext";
import type { TranslationKey } from "@/lib/translations";
import { cn } from "@/lib/utils";
import { Link, useRouterState } from "@tanstack/react-router";
import { Leaf } from "lucide-react";
import { Camera, Globe, Home, MessageCircle, Sprout } from "lucide-react";

const navItems: Array<{
  path: string;
  labelKey: TranslationKey;
  Icon: React.ComponentType<{ className?: string }>;
}> = [
  { path: "/home", labelKey: "home", Icon: Home },
  { path: "/query", labelKey: "query", Icon: MessageCircle },
  { path: "/upload", labelKey: "upload", Icon: Camera },
  { path: "/crops", labelKey: "crops", Icon: Sprout },
];

function Header() {
  const { t, languageInfo } = useLanguage();
  const [showLangPicker, setShowLangPicker] = React.useState(false);

  return (
    <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-primary rounded-lg flex items-center justify-center">
            <Leaf className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-display font-bold text-lg leading-tight text-foreground">
              {t("appName")}
            </h1>
            <p className="text-xs text-muted-foreground leading-none">
              {t("tagline")}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowLangPicker(true)}
          data-ocid="header.language_toggle"
          className="touch-target rounded-lg px-3 gap-1.5 text-sm font-medium text-foreground hover:bg-muted transition-colors flex items-center"
          aria-label={t("changeLanguage")}
        >
          <Globe className="w-4 h-4 text-primary" />
          <span className="text-xs font-display">
            {languageInfo.nativeName}
          </span>
        </button>
      </div>
      {showLangPicker && (
        <LanguagePickerOverlay onClose={() => setShowLangPicker(false)} />
      )}
    </header>
  );
}

function LanguagePickerOverlay({ onClose }: { onClose: () => void }) {
  const { setLanguage, language } = useLanguage();

  return (
    // biome-ignore lint/a11y/useKeyWithClickEvents: overlay backdrop dismiss
    <div
      className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm flex items-end sm:items-center justify-center"
      onClick={onClose}
      data-ocid="language_picker.dialog"
    >
      {/* biome-ignore lint/a11y/useKeyWithClickEvents: stop propagation */}
      <div
        className="bg-card rounded-t-2xl sm:rounded-2xl w-full sm:max-w-sm max-h-[70vh] overflow-y-auto p-4 shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="grid grid-cols-2 gap-2 pb-4">
          {LANGUAGES.map((lang: import("@/lib/translations").Language) => (
            <button
              key={lang.code}
              type="button"
              data-ocid={`language_picker.item.${lang.code}`}
              onClick={() => {
                setLanguage(lang.code);
                onClose();
              }}
              className={cn(
                "flex flex-col items-center gap-1 p-3 rounded-xl border transition-smooth touch-target",
                lang.code === language
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border hover:border-primary/40 hover:bg-muted",
              )}
            >
              <span className="text-xl">{lang.flag}</span>
              <span className="text-sm font-display font-semibold leading-tight">
                {lang.nativeName}
              </span>
              <span className="text-[10px] text-muted-foreground">
                {lang.name}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function BottomNav() {
  const { t } = useLanguage();
  const router = useRouterState();
  const currentPath = router.location.pathname;

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border"
      aria-label="Bottom navigation"
    >
      <div className="flex items-stretch">
        {navItems.map(({ path, labelKey, Icon }) => {
          const isActive =
            currentPath === path ||
            (path !== "/home" && currentPath.startsWith(path));
          return (
            <Link
              key={path}
              to={path}
              data-ocid={`nav.${labelKey}`}
              className={cn(
                "flex-1 flex flex-col items-center justify-center gap-0.5 py-2 min-h-[56px] transition-colors",
                isActive
                  ? "text-primary bg-primary/8"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted",
              )}
              aria-current={isActive ? "page" : undefined}
            >
              <Icon className={cn("w-5 h-5", isActive && "drop-shadow-sm")} />
              <span className="text-[10px] font-medium leading-none mt-0.5 truncate max-w-[4rem] text-center">
                {t(labelKey)}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export interface LayoutProps {
  children: React.ReactNode;
  hideNav?: boolean;
}

import React from "react";

export function Layout({ children, hideNav = false }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 pb-16" id="main-content">
        {children}
      </main>
      {!hideNav && <BottomNav />}
    </div>
  );
}
