import { LANGUAGES, useLanguage } from "@/contexts/LanguageContext";
import type { LanguageCode } from "@/lib/translations";
import { cn } from "@/lib/utils";
import { ChevronRight, Leaf } from "lucide-react";
import { motion } from "motion/react";
import React from "react";

interface LanguageSelectorProps {
  onSelect: (code: LanguageCode) => void;
}

export function LanguageSelector({ onSelect }: LanguageSelectorProps) {
  const { language, setLanguage, t } = useLanguage();
  const [selected, setSelected] = React.useState<LanguageCode>(language);

  function handleContinue() {
    setLanguage(selected);
    onSelect(selected);
  }

  return (
    <div
      className="min-h-screen bg-background flex flex-col"
      data-ocid="language_selector.page"
    >
      {/* Hero Header */}
      <div className="bg-card border-b border-border px-6 pt-10 pb-6">
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="flex flex-col items-center text-center gap-3"
        >
          <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center shadow-md">
            <Leaf className="w-9 h-9 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-display font-bold text-3xl text-foreground">
              FarmBuddy
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              अपनी भाषा चुनें · Choose Your Language
            </p>
          </div>
        </motion.div>
      </div>

      {/* Language Grid */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div
          className="grid grid-cols-2 gap-3"
          data-ocid="language_selector.list"
        >
          {LANGUAGES.map((lang, i) => (
            <motion.button
              key={lang.code}
              type="button"
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.25, delay: i * 0.04 }}
              onClick={() => setSelected(lang.code)}
              data-ocid={`language_selector.item.${lang.code}`}
              className={cn(
                "relative flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-smooth min-h-[88px]",
                selected === lang.code
                  ? "border-primary bg-primary/10 shadow-sm"
                  : "border-border bg-card hover:border-primary/40 hover:bg-muted active:scale-95",
              )}
            >
              {selected === lang.code && (
                <span className="absolute top-2 right-2 w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-[8px] text-primary-foreground font-bold">
                    ✓
                  </span>
                </span>
              )}
              <span className="text-2xl">{lang.flag}</span>
              <span
                className={cn(
                  "font-display font-bold text-base leading-tight text-center",
                  selected === lang.code ? "text-primary" : "text-foreground",
                )}
              >
                {lang.nativeName}
              </span>
              <span className="text-[11px] text-muted-foreground">
                {lang.name}
              </span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* CTA Footer */}
      <div className="sticky bottom-0 bg-card border-t border-border px-4 py-4">
        <motion.button
          type="button"
          whileTap={{ scale: 0.97 }}
          onClick={handleContinue}
          data-ocid="language_selector.continue_button"
          className="w-full flex items-center justify-center gap-2 py-4 bg-primary text-primary-foreground font-display font-bold text-lg rounded-2xl shadow-md hover:opacity-90 transition-smooth touch-target"
        >
          <span>{t("continueBtn")}</span>
          <ChevronRight className="w-5 h-5" />
        </motion.button>
      </div>
    </div>
  );
}
