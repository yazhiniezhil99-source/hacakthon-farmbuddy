import type { LanguageCode } from "@/lib/translations";
import { LANGUAGES, getLanguage, t as translate } from "@/lib/translations";
import type { Language, TranslationKey } from "@/lib/translations";
import type React from "react";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

const SESSION_KEY = "farmbuddy_lang";

interface LanguageContextValue {
  language: LanguageCode;
  languageInfo: Language;
  setLanguage: (code: LanguageCode) => void;
  t: (key: TranslationKey) => string;
  isRtl: boolean;
  hasSelectedLanguage: boolean;
}

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const stored = sessionStorage.getItem(SESSION_KEY) as LanguageCode | null;
  const [language, setLang] = useState<LanguageCode>(stored ?? "hi");
  const [hasSelectedLanguage, setHasSelectedLanguage] = useState(
    stored !== null,
  );

  const setLanguage = useCallback((code: LanguageCode) => {
    sessionStorage.setItem(SESSION_KEY, code);
    setLang(code);
    setHasSelectedLanguage(true);
  }, []);

  const t = useCallback(
    (key: TranslationKey) => translate(language, key),
    [language],
  );

  const isRtl = language === "ur";

  useEffect(() => {
    document.documentElement.setAttribute("lang", language);
    document.documentElement.setAttribute("dir", isRtl ? "rtl" : "ltr");
  }, [language, isRtl]);

  return (
    <LanguageContext.Provider
      value={{
        language,
        languageInfo: getLanguage(language),
        setLanguage,
        t,
        isRtl,
        hasSelectedLanguage,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage(): LanguageContextValue {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used inside LanguageProvider");
  return ctx;
}

export { LANGUAGES };
